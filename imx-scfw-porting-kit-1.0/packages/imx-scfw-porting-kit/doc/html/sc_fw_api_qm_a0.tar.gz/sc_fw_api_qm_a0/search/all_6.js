var searchData=
[
  ['resource_20list',['Resource List',['../RESOURCES.html',1,'']]]
];
