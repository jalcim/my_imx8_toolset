var structlpi2c__data__match__config__t =
[
    [ "matchMode", "structlpi2c__data__match__config__t.html#a1ee7d6261dcde31818b381f189569d80", null ],
    [ "rxDataMatchOnly", "structlpi2c__data__match__config__t.html#a2d2eed3e5f6fb4a94b653f416818ae30", null ],
    [ "match0", "structlpi2c__data__match__config__t.html#ad28aaeb70cf478b4564cc05da64ce062", null ],
    [ "match1", "structlpi2c__data__match__config__t.html#a8062fa234f06a2888f04dc95dab28240", null ]
];