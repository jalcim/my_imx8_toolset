var structgpio__pin__config__t =
[
    [ "pinDirection", "structgpio__pin__config__t.html#a70aed128003103272f5740f12fbff525", null ],
    [ "outputLogic", "structgpio__pin__config__t.html#a9d37ffd9a2943f10a91095759bd52da5", null ]
];