var modules =
[
    [ "(DRV) General-Purpose Input/Output", "group__gpio.html", "group__gpio" ],
    [ "(DRV) Low Power I2C Driver", "group__lpi2c__driver.html", "group__lpi2c__driver" ],
    [ "(DRV) Power Management IC Driver", "group__pmic__driver.html", "group__pmic__driver" ],
    [ "(DRV) PF100 Power Management IC Driver", "group__pf100__driver.html", "group__pf100__driver" ],
    [ "(DRV) PF8100 Power Management IC Driver", "group__pf8100__driver.html", "group__pf8100__driver" ],
    [ "(SVC) Pad Service", "group__PAD__SVC.html", "group__PAD__SVC" ],
    [ "(SVC) Timer Service", "group__TIMER__SVC.html", "group__TIMER__SVC" ],
    [ "(SVC) Power Management Service", "group__PM__SVC.html", "group__PM__SVC" ],
    [ "(SVC) Interrupt Service", "group__IRQ__SVC.html", "group__IRQ__SVC" ],
    [ "(SVC) Miscellaneous Service", "group__MISC__SVC.html", "group__MISC__SVC" ],
    [ "(SVC) Resource Management Service", "group__RM__SVC.html", "group__RM__SVC" ],
    [ "(BRD) Board Interface", "group__BRD__SVC.html", "group__BRD__SVC" ]
];