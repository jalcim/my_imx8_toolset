var dir_0212de942c66fc701dc689b9ed333526 =
[
    [ "board.h", "board_8h.html", "board_8h" ],
    [ "ipc.h", "ipc_8h.html", "ipc_8h" ],
    [ "types.h", "types_8h.html", "types_8h" ]
];