var annotated_dup =
[
    [ "gpio_pin_config_t", "structgpio__pin__config__t.html", "structgpio__pin__config__t" ],
    [ "lpi2c_data_match_config_t", "structlpi2c__data__match__config__t.html", "structlpi2c__data__match__config__t" ],
    [ "lpi2c_master_config_t", "structlpi2c__master__config__t.html", "structlpi2c__master__config__t" ],
    [ "lpi2c_master_handle_t", "struct__lpi2c__master__handle.html", "struct__lpi2c__master__handle" ],
    [ "lpi2c_master_transfer_t", "struct__lpi2c__master__transfer.html", "struct__lpi2c__master__transfer" ],
    [ "lpi2c_slave_config_t", "structlpi2c__slave__config__t.html", "structlpi2c__slave__config__t" ],
    [ "lpi2c_slave_handle_t", "struct__lpi2c__slave__handle.html", "struct__lpi2c__slave__handle" ],
    [ "lpi2c_slave_transfer_t", "structlpi2c__slave__transfer__t.html", "structlpi2c__slave__transfer__t" ],
    [ "pmic_version_t", "structpmic__version__t.html", "structpmic__version__t" ]
];