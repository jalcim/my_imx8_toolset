var group__pmic__driver =
[
    [ "fsl_pmic.h", "fsl__pmic_8h.html", null ],
    [ "pmic_version_t", "structpmic__version__t.html", [
      [ "device_id", "structpmic__version__t.html#a0e79948977e8ba28b2dddd586c797280", null ],
      [ "si_rev", "structpmic__version__t.html#a94181a4131beda3f0396fff16fc23192", null ]
    ] ],
    [ "pmic_id_t", "group__pmic__driver.html#ga644afb90d81923ab59d4b4816cf6a2fd", null ],
    [ "dynamic_pmic_set_voltage", "group__pmic__driver.html#ga6b465688ec281d30054e1f8403efca4d", null ],
    [ "dynamic_pmic_get_voltage", "group__pmic__driver.html#gae489a6a6ba8340bfa9ac08da8b5b51e5", null ],
    [ "dynamic_pmic_set_mode", "group__pmic__driver.html#ga195c01641dccf68132e3e5fd33f21ad2", null ],
    [ "dynamic_pmic_get_mode", "group__pmic__driver.html#ga00494b72e68cf1f1b47bf07984d0c348", null ],
    [ "dynamic_pmic_irq_service", "group__pmic__driver.html#ga1d8db1cf9b3fd8036d5bb3b07dcc37c5", null ],
    [ "dynamic_pmic_register_access", "group__pmic__driver.html#ga6e5dc284afc738c9a2d9426b9d81b8ca", null ],
    [ "dynamic_get_pmic_version", "group__pmic__driver.html#ga2480027c8d56d0648e2f116adbf094ff", null ],
    [ "dynamic_get_pmic_temp", "group__pmic__driver.html#ga235f7c3c95601440e171d41a1bd9f82a", null ],
    [ "dynamic_set_pmic_temp_alarm", "group__pmic__driver.html#gacd726831ca9349a17680537ee5d41f90", null ],
    [ "i2c_write_sub", "group__pmic__driver.html#gae20f1b02fa6d0f9b1cd191689263aea8", null ],
    [ "i2c_write", "group__pmic__driver.html#gad3a8740d97646ddda9bc64af70d82ca7", null ],
    [ "i2c_read_sub", "group__pmic__driver.html#ga4bb1475f8d1f66b8bd1f37ac38a93dac", null ],
    [ "i2c_read", "group__pmic__driver.html#gae2802e3960c2c8cad9562496b2ef8139", null ],
    [ "pmic_get_device_id", "group__pmic__driver.html#ga4408e93d28a91b01bd5bd5eab34610b6", null ],
    [ "PMIC_TYPE", "group__pmic__driver.html#ga839f3bb26ac2c7c0b3fddb7d9b6e1eba", null ]
];