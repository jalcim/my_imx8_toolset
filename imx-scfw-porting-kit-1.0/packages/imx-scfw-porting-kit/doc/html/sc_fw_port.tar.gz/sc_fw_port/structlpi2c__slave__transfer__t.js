var structlpi2c__slave__transfer__t =
[
    [ "event", "structlpi2c__slave__transfer__t.html#a19df3bc5c35ed8ae03a927dcc89daa48", null ],
    [ "receivedAddress", "structlpi2c__slave__transfer__t.html#a336e15a483043ed7ace990517fff6686", null ],
    [ "data", "structlpi2c__slave__transfer__t.html#a54436075594000b4d56471b29dd6734f", null ],
    [ "dataSize", "structlpi2c__slave__transfer__t.html#afcd4de20f8efd725bd93d72180b32f2d", null ],
    [ "completionStatus", "structlpi2c__slave__transfer__t.html#aafd14bc835c1c23de6bf06834d1a0b3c", null ],
    [ "transferredCount", "structlpi2c__slave__transfer__t.html#a67e03ab90367cb1d48d42b718e6438f5", null ]
];