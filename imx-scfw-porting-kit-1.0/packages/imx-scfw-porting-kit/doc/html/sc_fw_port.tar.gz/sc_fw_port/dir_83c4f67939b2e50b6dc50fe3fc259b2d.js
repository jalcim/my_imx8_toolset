var dir_83c4f67939b2e50b6dc50fe3fc259b2d =
[
    [ "gpio", "dir_b07b1803b08e3bfa8752acf7d436415b.html", "dir_b07b1803b08e3bfa8752acf7d436415b" ],
    [ "lpi2c", "dir_9986937d5c2d55a7e5d1d4820166229f.html", "dir_9986937d5c2d55a7e5d1d4820166229f" ],
    [ "pmic", "dir_c3bcce33382019f75311cf08b00f60e6.html", "dir_c3bcce33382019f75311cf08b00f60e6" ]
];