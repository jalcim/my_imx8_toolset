var searchData=
[
  ['i2c_5fread',['i2c_read',['../group__pmic__driver.html#gae2802e3960c2c8cad9562496b2ef8139',1,'fsl_pmic.h']]],
  ['i2c_5fread_5fsub',['i2c_read_sub',['../group__pmic__driver.html#ga4bb1475f8d1f66b8bd1f37ac38a93dac',1,'fsl_pmic.h']]],
  ['i2c_5fwrite',['i2c_write',['../group__pmic__driver.html#gad3a8740d97646ddda9bc64af70d82ca7',1,'fsl_pmic.h']]],
  ['i2c_5fwrite_5fsub',['i2c_write_sub',['../group__pmic__driver.html#gae20f1b02fa6d0f9b1cd191689263aea8',1,'fsl_pmic.h']]]
];
