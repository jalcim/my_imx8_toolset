var searchData=
[
  ['data',['data',['../struct__lpi2c__master__transfer.html#a6f242bd0a1ce4821c7d1d26074b29a9d',1,'_lpi2c_master_transfer::data()'],['../structlpi2c__slave__transfer__t.html#a54436075594000b4d56471b29dd6734f',1,'lpi2c_slave_transfer_t::data()']]],
  ['datasize',['dataSize',['../struct__lpi2c__master__transfer.html#a79682c750a97b52d05515165f3f530e1',1,'_lpi2c_master_transfer::dataSize()'],['../structlpi2c__slave__transfer__t.html#afcd4de20f8efd725bd93d72180b32f2d',1,'lpi2c_slave_transfer_t::dataSize()']]],
  ['datavaliddelay_5fns',['dataValidDelay_ns',['../structlpi2c__slave__config__t.html#a920288e7667b3b363f019384ebc58606',1,'lpi2c_slave_config_t']]],
  ['debugenable',['debugEnable',['../structlpi2c__master__config__t.html#a73c9f8dca26ed429fb5df6eebbb757b1',1,'lpi2c_master_config_t']]],
  ['device_5fid',['device_id',['../structpmic__version__t.html#a0e79948977e8ba28b2dddd586c797280',1,'pmic_version_t']]],
  ['direction',['direction',['../struct__lpi2c__master__transfer.html#af9c1114cb5c6834f07c2069e39faba17',1,'_lpi2c_master_transfer']]]
];
