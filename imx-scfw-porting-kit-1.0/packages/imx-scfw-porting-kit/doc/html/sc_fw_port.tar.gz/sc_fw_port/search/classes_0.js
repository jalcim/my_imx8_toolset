var searchData=
[
  ['_5flpi2c_5fmaster_5fhandle',['_lpi2c_master_handle',['../struct__lpi2c__master__handle.html',1,'']]],
  ['_5flpi2c_5fmaster_5ftransfer',['_lpi2c_master_transfer',['../struct__lpi2c__master__transfer.html',1,'']]],
  ['_5flpi2c_5fslave_5fhandle',['_lpi2c_slave_handle',['../struct__lpi2c__slave__handle.html',1,'']]]
];
