var searchData=
[
  ['vgen_5fpmic_5fmode_5ft',['vgen_pmic_mode_t',['../group__pf100__driver.html#ga5c080470c4eec2bfe04b86ac9e7df69e',1,'fsl_pf100.h']]],
  ['vmode_5freg_5ft',['vmode_reg_t',['../group__pf8100__driver.html#gaa5b6752c5fdfe14ee816110942d6205d',1,'fsl_pf8100.h']]]
];
