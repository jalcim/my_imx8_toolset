var searchData=
[
  ['uint16_5ft',['uint16_t',['../types_8h.html#a5debae8b2a1ec20a6694c0c443ee399e',1,'types.h']]],
  ['uint32_5ft',['uint32_t',['../types_8h.html#a0a8582351ac627ee8bde2973c825e47f',1,'types.h']]],
  ['uint64_5ft',['uint64_t',['../types_8h.html#a2095b9bffea4b2656950c6c0419edbf1',1,'types.h']]],
  ['uint8_5ft',['uint8_t',['../types_8h.html#a3cb4a16b0e8d6af0af86d4fd6ba5fd9d',1,'types.h']]],
  ['usage',['Usage',['../USAGE.html',1,'']]],
  ['userdata',['userData',['../struct__lpi2c__master__handle.html#a6891adb76d1887f61142ecc89815dcd4',1,'_lpi2c_master_handle::userData()'],['../struct__lpi2c__slave__handle.html#aa394f46d8677c977aa39b64fb0c353ce',1,'_lpi2c_slave_handle::userData()']]]
];
