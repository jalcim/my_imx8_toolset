var searchData=
[
  ['pinconfig',['pinConfig',['../structlpi2c__master__config__t.html#abf68fadb2fd229f0fd034e1961935ee4',1,'lpi2c_master_config_t']]],
  ['pindirection',['pinDirection',['../structgpio__pin__config__t.html#a70aed128003103272f5740f12fbff525',1,'gpio_pin_config_t']]],
  ['pinlowtimeout_5fns',['pinLowTimeout_ns',['../structlpi2c__master__config__t.html#aa7788a850bf2ff954320368b237221ee',1,'lpi2c_master_config_t']]],
  ['pmic_5ftype',['PMIC_TYPE',['../group__pmic__driver.html#ga839f3bb26ac2c7c0b3fddb7d9b6e1eba',1,'pmic.h']]],
  ['polarity',['polarity',['../structlpi2c__master__config__t.html#acb38f33f1c5f33595cae1133882c4d24',1,'lpi2c_master_config_t']]]
];
