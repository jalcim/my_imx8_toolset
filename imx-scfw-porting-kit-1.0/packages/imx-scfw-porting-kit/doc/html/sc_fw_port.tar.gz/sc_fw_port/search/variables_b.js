var searchData=
[
  ['receivedaddress',['receivedAddress',['../structlpi2c__slave__transfer__t.html#a336e15a483043ed7ace990517fff6686',1,'lpi2c_slave_transfer_t']]],
  ['remainingbytes',['remainingBytes',['../struct__lpi2c__master__handle.html#a5a35aa5dfb9d0b99bf6b63d8ca2d0571',1,'_lpi2c_master_handle']]],
  ['rxdatamatchonly',['rxDataMatchOnly',['../structlpi2c__data__match__config__t.html#a2d2eed3e5f6fb4a94b653f416818ae30',1,'lpi2c_data_match_config_t']]]
];
