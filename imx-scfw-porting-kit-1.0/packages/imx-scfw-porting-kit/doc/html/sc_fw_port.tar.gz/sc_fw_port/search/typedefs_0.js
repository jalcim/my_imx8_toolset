var searchData=
[
  ['board_5fparm_5frtn_5ft',['board_parm_rtn_t',['../group__BRD__SVC.html#ga7146ee062ffdae1ef72540367633712d',1,'board.h']]]
];
