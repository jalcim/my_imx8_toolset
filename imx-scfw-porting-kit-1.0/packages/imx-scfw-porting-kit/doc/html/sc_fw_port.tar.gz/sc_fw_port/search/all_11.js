var searchData=
[
  ['transfer',['transfer',['../struct__lpi2c__master__handle.html#a9c451e008467a29718e70cbc3c978a0c',1,'_lpi2c_master_handle::transfer()'],['../struct__lpi2c__slave__handle.html#aed2dec763e40c6caa129c082603852d5',1,'_lpi2c_slave_handle::transfer()']]],
  ['transferredcount',['transferredCount',['../structlpi2c__slave__transfer__t.html#a67e03ab90367cb1d48d42b718e6438f5',1,'lpi2c_slave_transfer_t::transferredCount()'],['../struct__lpi2c__slave__handle.html#ac9f4d0665e8ec4c56eb89e816c4b5324',1,'_lpi2c_slave_handle::transferredCount()']]],
  ['types_2eh',['types.h',['../types_8h.html',1,'']]]
];
