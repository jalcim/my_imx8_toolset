var searchData=
[
  ['match0',['match0',['../structlpi2c__data__match__config__t.html#ad28aaeb70cf478b4564cc05da64ce062',1,'lpi2c_data_match_config_t']]],
  ['match1',['match1',['../structlpi2c__data__match__config__t.html#a8062fa234f06a2888f04dc95dab28240',1,'lpi2c_data_match_config_t']]],
  ['matchmode',['matchMode',['../structlpi2c__data__match__config__t.html#a1ee7d6261dcde31818b381f189569d80',1,'lpi2c_data_match_config_t']]]
];
