var searchData=
[
  ['callback',['callback',['../struct__lpi2c__slave__handle.html#a0e16ba71a57adfe84058af632a604e40',1,'_lpi2c_slave_handle']]],
  ['clockholdtime_5fns',['clockHoldTime_ns',['../structlpi2c__slave__config__t.html#a2e672f5446e7d86eb9d74bdc785df0fb',1,'lpi2c_slave_config_t']]],
  ['commandbuffer',['commandBuffer',['../struct__lpi2c__master__handle.html#ad4580490ec11fe2ce2f12143a5ad55a0',1,'_lpi2c_master_handle']]],
  ['completioncallback',['completionCallback',['../struct__lpi2c__master__handle.html#a45504c346312e5b6d8f0ee3e2a9be3c6',1,'_lpi2c_master_handle']]],
  ['completionstatus',['completionStatus',['../structlpi2c__slave__transfer__t.html#aafd14bc835c1c23de6bf06834d1a0b3c',1,'lpi2c_slave_transfer_t']]]
];
