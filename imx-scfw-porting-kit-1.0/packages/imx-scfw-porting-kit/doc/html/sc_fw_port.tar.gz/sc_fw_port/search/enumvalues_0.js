var searchData=
[
  ['board_5fddr_5fcold_5finit',['BOARD_DDR_COLD_INIT',['../group__BRD__SVC.html#gga4671494038a12aef57ddd16bcac865e5a05664e1dcf94ae753e4cb26906124c1d',1,'board.h']]],
  ['board_5fddr_5fperiodic',['BOARD_DDR_PERIODIC',['../group__BRD__SVC.html#gga4671494038a12aef57ddd16bcac865e5ada21f04994afe5aca335b6678131aaeb',1,'board.h']]],
  ['board_5fddr_5fsr_5fdrc_5foff_5fenter',['BOARD_DDR_SR_DRC_OFF_ENTER',['../group__BRD__SVC.html#gga4671494038a12aef57ddd16bcac865e5ae57e39078f6fe3710d912aa10d01da85',1,'board.h']]],
  ['board_5fddr_5fsr_5fdrc_5foff_5fexit',['BOARD_DDR_SR_DRC_OFF_EXIT',['../group__BRD__SVC.html#gga4671494038a12aef57ddd16bcac865e5a27a638e43d7ced62a855ac86082c064b',1,'board.h']]],
  ['board_5fddr_5fsr_5fdrc_5fon_5fenter',['BOARD_DDR_SR_DRC_ON_ENTER',['../group__BRD__SVC.html#gga4671494038a12aef57ddd16bcac865e5a466a431244a4d0d6f0b5821432718b5a',1,'board.h']]],
  ['board_5fddr_5fsr_5fdrc_5fon_5fexit',['BOARD_DDR_SR_DRC_ON_EXIT',['../group__BRD__SVC.html#gga4671494038a12aef57ddd16bcac865e5a000a807b63b31bf182330eafd93eafe2',1,'board.h']]],
  ['board_5fparm_5fks1_5fonoff_5fwake',['BOARD_PARM_KS1_ONOFF_WAKE',['../group__BRD__SVC.html#gga5e7d1f30c9c3c0a5cbc48a0fc0cf8caba006b525e8eeb9fe1134f013a5bc646c8',1,'board.h']]],
  ['board_5fparm_5fks1_5fresume_5fusec',['BOARD_PARM_KS1_RESUME_USEC',['../group__BRD__SVC.html#gga5e7d1f30c9c3c0a5cbc48a0fc0cf8caba5911fcc0de212e557deaeb4fdea18270',1,'board.h']]],
  ['board_5fparm_5fks1_5fretention',['BOARD_PARM_KS1_RETENTION',['../group__BRD__SVC.html#gga5e7d1f30c9c3c0a5cbc48a0fc0cf8caba528cfc11f03bc45782b484ad0b1e8ff6',1,'board.h']]]
];
