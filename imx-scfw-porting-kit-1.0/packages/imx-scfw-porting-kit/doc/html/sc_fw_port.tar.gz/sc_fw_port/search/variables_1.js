var searchData=
[
  ['baudrate_5fhz',['baudRate_Hz',['../structlpi2c__master__config__t.html#a2f8d353d1e637b082ad8ebe978a4d6b9',1,'lpi2c_master_config_t']]],
  ['board_5fddr_5fperiod_5fms',['board_ddr_period_ms',['../group__BRD__SVC.html#gaeed3cb4abf61c07206c37f557ff3c882',1,'board.h']]],
  ['board_5fnum_5frsrc',['board_num_rsrc',['../group__BRD__SVC.html#ga56f277a67446885bcb87178c97e5d4b6',1,'board.h']]],
  ['board_5frsrc_5fmap',['board_rsrc_map',['../group__BRD__SVC.html#ga088c25dbfb6305b6ad0feeb38d710fcd',1,'board.h']]],
  ['buf',['buf',['../struct__lpi2c__master__handle.html#abdfd4fa41631d38f85d4bb5d9d2b8881',1,'_lpi2c_master_handle']]],
  ['busidletimeout_5fns',['busIdleTimeout_ns',['../structlpi2c__master__config__t.html#a936409ced864d404b3fdf0f66144ccd9',1,'lpi2c_master_config_t']]]
];
