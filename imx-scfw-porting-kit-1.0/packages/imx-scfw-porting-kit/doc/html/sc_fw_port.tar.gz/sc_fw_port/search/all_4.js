var searchData=
[
  ['data',['data',['../struct__lpi2c__master__transfer.html#a6f242bd0a1ce4821c7d1d26074b29a9d',1,'_lpi2c_master_transfer::data()'],['../structlpi2c__slave__transfer__t.html#a54436075594000b4d56471b29dd6734f',1,'lpi2c_slave_transfer_t::data()']]],
  ['datasize',['dataSize',['../struct__lpi2c__master__transfer.html#a79682c750a97b52d05515165f3f530e1',1,'_lpi2c_master_transfer::dataSize()'],['../structlpi2c__slave__transfer__t.html#afcd4de20f8efd725bd93d72180b32f2d',1,'lpi2c_slave_transfer_t::dataSize()']]],
  ['datavaliddelay_5fns',['dataValidDelay_ns',['../structlpi2c__slave__config__t.html#a920288e7667b3b363f019384ebc58606',1,'lpi2c_slave_config_t']]],
  ['debugenable',['debugEnable',['../structlpi2c__master__config__t.html#a73c9f8dca26ed429fb5df6eebbb757b1',1,'lpi2c_master_config_t']]],
  ['device_5fid',['device_id',['../structpmic__version__t.html#a0e79948977e8ba28b2dddd586c797280',1,'pmic_version_t']]],
  ['direction',['direction',['../struct__lpi2c__master__transfer.html#af9c1114cb5c6834f07c2069e39faba17',1,'_lpi2c_master_transfer']]],
  ['disclaimer',['Disclaimer',['../DISCLAIMER.html',1,'']]],
  ['dynamic_5fget_5fpmic_5ftemp',['dynamic_get_pmic_temp',['../group__pmic__driver.html#ga235f7c3c95601440e171d41a1bd9f82a',1,'pmic.h']]],
  ['dynamic_5fget_5fpmic_5fversion',['dynamic_get_pmic_version',['../group__pmic__driver.html#ga2480027c8d56d0648e2f116adbf094ff',1,'pmic.h']]],
  ['dynamic_5fpmic_5fget_5fmode',['dynamic_pmic_get_mode',['../group__pmic__driver.html#ga00494b72e68cf1f1b47bf07984d0c348',1,'pmic.h']]],
  ['dynamic_5fpmic_5fget_5fvoltage',['dynamic_pmic_get_voltage',['../group__pmic__driver.html#gae489a6a6ba8340bfa9ac08da8b5b51e5',1,'pmic.h']]],
  ['dynamic_5fpmic_5firq_5fservice',['dynamic_pmic_irq_service',['../group__pmic__driver.html#ga1d8db1cf9b3fd8036d5bb3b07dcc37c5',1,'pmic.h']]],
  ['dynamic_5fpmic_5fregister_5faccess',['dynamic_pmic_register_access',['../group__pmic__driver.html#ga6e5dc284afc738c9a2d9426b9d81b8ca',1,'pmic.h']]],
  ['dynamic_5fpmic_5fset_5fmode',['dynamic_pmic_set_mode',['../group__pmic__driver.html#ga195c01641dccf68132e3e5fd33f21ad2',1,'pmic.h']]],
  ['dynamic_5fpmic_5fset_5fvoltage',['dynamic_pmic_set_voltage',['../group__pmic__driver.html#ga6b465688ec281d30054e1f8403efca4d',1,'pmic.h']]],
  ['dynamic_5fset_5fpmic_5ftemp_5falarm',['dynamic_set_pmic_temp_alarm',['../group__pmic__driver.html#gacd726831ca9349a17680537ee5d41f90',1,'pmic.h']]],
  ['debug_20monitor',['Debug Monitor',['../EXPORT_DEBUG_MONITOR.html',1,'']]]
];
