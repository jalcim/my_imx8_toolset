var searchData=
[
  ['sclglitchfilterwidth_5fns',['sclGlitchFilterWidth_ns',['../structlpi2c__master__config__t.html#abec5caf29a17c3cd3480e5b1b07f742a',1,'lpi2c_master_config_t::sclGlitchFilterWidth_ns()'],['../structlpi2c__slave__config__t.html#a793ea7dd26bfb1f68daae2523e70d5a5',1,'lpi2c_slave_config_t::sclGlitchFilterWidth_ns()']]],
  ['sdaglitchfilterwidth_5fns',['sdaGlitchFilterWidth_ns',['../structlpi2c__master__config__t.html#a6b20d7345badb866950662d13177f137',1,'lpi2c_master_config_t::sdaGlitchFilterWidth_ns()'],['../structlpi2c__slave__config__t.html#a7c28ef56af23d2e059942e8d80e5cd15',1,'lpi2c_slave_config_t::sdaGlitchFilterWidth_ns()']]],
  ['si_5frev',['si_rev',['../structpmic__version__t.html#a94181a4131beda3f0396fff16fc23192',1,'pmic_version_t']]],
  ['slaveaddress',['slaveAddress',['../struct__lpi2c__master__transfer.html#a7b9a1f78b5cf27502969224775e2134b',1,'_lpi2c_master_transfer']]],
  ['source',['source',['../structlpi2c__master__config__t.html#a2c56d9865a4d122894a4918b21540151',1,'lpi2c_master_config_t']]],
  ['state',['state',['../struct__lpi2c__master__handle.html#aa754ef003d1639ef78a69dbe450c9e72',1,'_lpi2c_master_handle']]],
  ['subaddress',['subaddress',['../struct__lpi2c__master__transfer.html#a377ed24db3b848a1253bc9a5344e732f',1,'_lpi2c_master_transfer']]],
  ['subaddresssize',['subaddressSize',['../struct__lpi2c__master__transfer.html#abb7feabae4704bcf7b090d50b6d9c951',1,'_lpi2c_master_transfer']]]
];
