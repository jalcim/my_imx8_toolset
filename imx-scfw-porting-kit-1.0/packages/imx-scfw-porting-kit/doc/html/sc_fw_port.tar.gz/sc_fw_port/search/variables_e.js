var searchData=
[
  ['userdata',['userData',['../struct__lpi2c__master__handle.html#a6891adb76d1887f61142ecc89815dcd4',1,'_lpi2c_master_handle::userData()'],['../struct__lpi2c__slave__handle.html#aa394f46d8677c977aa39b64fb0c353ce',1,'_lpi2c_slave_handle::userData()']]]
];
