var searchData=
[
  ['ignoreack',['ignoreAck',['../structlpi2c__master__config__t.html#af66e69bf2cf504a3f420774a2ee3456b',1,'lpi2c_master_config_t::ignoreAck()'],['../structlpi2c__slave__config__t.html#ae68493537f90f7bff4a421ff534fb7a1',1,'lpi2c_slave_config_t::ignoreAck()']]],
  ['isbusy',['isBusy',['../struct__lpi2c__slave__handle.html#a8f0662c2c78df7b8e8b5ed4c1119823d',1,'_lpi2c_slave_handle']]]
];
