var searchData=
[
  ['vgen1',['VGEN1',['../group__pf100__driver.html#ga87004651cb82cccaddf47b645a65ec0c',1,'fsl_pf100.h']]],
  ['vgen2',['VGEN2',['../group__pf100__driver.html#ga8a7c39beff129e51bf35c0965e384679',1,'fsl_pf100.h']]],
  ['vgen3',['VGEN3',['../group__pf100__driver.html#ga7482d45d797f6677ae6b44dcc42f9212',1,'fsl_pf100.h']]],
  ['vgen4',['VGEN4',['../group__pf100__driver.html#gabeb53a7bf1cc25e1b0815d1725f34523',1,'fsl_pf100.h']]],
  ['vgen5',['VGEN5',['../group__pf100__driver.html#ga962806824c98b390601d49a84be56afb',1,'fsl_pf100.h']]],
  ['vgen6',['VGEN6',['../group__pf100__driver.html#ga65d45968bd12bb1d787d9522d95f0069',1,'fsl_pf100.h']]],
  ['vgen_5fmode_5flp',['VGEN_MODE_LP',['../group__pf100__driver.html#ga32eee2d4bea82f45e57620ad0535a1ee',1,'fsl_pf100.h']]],
  ['vgen_5fmode_5flp2',['VGEN_MODE_LP2',['../group__pf100__driver.html#ga6a00547e2c8e162bf5ff3702534aab66',1,'fsl_pf100.h']]],
  ['vgen_5fmode_5foff',['VGEN_MODE_OFF',['../group__pf100__driver.html#ga7fff73a1455f9a4bddcdb29a4cc5003e',1,'fsl_pf100.h']]],
  ['vgen_5fmode_5fon',['VGEN_MODE_ON',['../group__pf100__driver.html#ga15c653fbd3fb656edc6f1e2f315f6f15',1,'fsl_pf100.h']]],
  ['vgen_5fmode_5fstby_5foff',['VGEN_MODE_STBY_OFF',['../group__pf100__driver.html#gad94b562abd57da54cc572d126698df98',1,'fsl_pf100.h']]],
  ['vgen_5fpmic_5fmode_5ft',['vgen_pmic_mode_t',['../group__pf100__driver.html#ga5c080470c4eec2bfe04b86ac9e7df69e',1,'fsl_pf100.h']]],
  ['vmode_5freg_5ft',['vmode_reg_t',['../group__pf8100__driver.html#gaa5b6752c5fdfe14ee816110942d6205d',1,'fsl_pf8100.h']]]
];
