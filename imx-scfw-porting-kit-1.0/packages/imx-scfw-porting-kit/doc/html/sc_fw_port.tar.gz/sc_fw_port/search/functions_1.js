var searchData=
[
  ['dynamic_5fget_5fpmic_5ftemp',['dynamic_get_pmic_temp',['../group__pmic__driver.html#ga235f7c3c95601440e171d41a1bd9f82a',1,'pmic.h']]],
  ['dynamic_5fget_5fpmic_5fversion',['dynamic_get_pmic_version',['../group__pmic__driver.html#ga2480027c8d56d0648e2f116adbf094ff',1,'pmic.h']]],
  ['dynamic_5fpmic_5fget_5fmode',['dynamic_pmic_get_mode',['../group__pmic__driver.html#ga00494b72e68cf1f1b47bf07984d0c348',1,'pmic.h']]],
  ['dynamic_5fpmic_5fget_5fvoltage',['dynamic_pmic_get_voltage',['../group__pmic__driver.html#gae489a6a6ba8340bfa9ac08da8b5b51e5',1,'pmic.h']]],
  ['dynamic_5fpmic_5firq_5fservice',['dynamic_pmic_irq_service',['../group__pmic__driver.html#ga1d8db1cf9b3fd8036d5bb3b07dcc37c5',1,'pmic.h']]],
  ['dynamic_5fpmic_5fregister_5faccess',['dynamic_pmic_register_access',['../group__pmic__driver.html#ga6e5dc284afc738c9a2d9426b9d81b8ca',1,'pmic.h']]],
  ['dynamic_5fpmic_5fset_5fmode',['dynamic_pmic_set_mode',['../group__pmic__driver.html#ga195c01641dccf68132e3e5fd33f21ad2',1,'pmic.h']]],
  ['dynamic_5fpmic_5fset_5fvoltage',['dynamic_pmic_set_voltage',['../group__pmic__driver.html#ga6b465688ec281d30054e1f8403efca4d',1,'pmic.h']]],
  ['dynamic_5fset_5fpmic_5ftemp_5falarm',['dynamic_set_pmic_temp_alarm',['../group__pmic__driver.html#gacd726831ca9349a17680537ee5d41f90',1,'pmic.h']]]
];
