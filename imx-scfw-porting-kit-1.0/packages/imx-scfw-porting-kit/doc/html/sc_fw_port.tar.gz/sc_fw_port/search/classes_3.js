var searchData=
[
  ['pmic_5fversion_5ft',['pmic_version_t',['../structpmic__version__t.html',1,'']]]
];
