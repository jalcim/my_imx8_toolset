var searchData=
[
  ['lpi2c_5fdata_5fmatch_5fconfig_5ft',['lpi2c_data_match_config_t',['../structlpi2c__data__match__config__t.html',1,'']]],
  ['lpi2c_5fmaster_5fconfig_5ft',['lpi2c_master_config_t',['../structlpi2c__master__config__t.html',1,'']]],
  ['lpi2c_5fslave_5fconfig_5ft',['lpi2c_slave_config_t',['../structlpi2c__slave__config__t.html',1,'']]],
  ['lpi2c_5fslave_5ftransfer_5ft',['lpi2c_slave_transfer_t',['../structlpi2c__slave__transfer__t.html',1,'']]]
];
