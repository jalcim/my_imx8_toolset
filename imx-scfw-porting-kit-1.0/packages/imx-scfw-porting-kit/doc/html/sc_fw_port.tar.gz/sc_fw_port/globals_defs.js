var globals_defs =
[
    [ "b", "globals_defs.html", null ],
    [ "f", "globals_defs_f.html", null ],
    [ "p", "globals_defs_p.html", null ],
    [ "r", "globals_defs_r.html", null ],
    [ "s", "globals_defs_s.html", null ],
    [ "v", "globals_defs_v.html", null ]
];