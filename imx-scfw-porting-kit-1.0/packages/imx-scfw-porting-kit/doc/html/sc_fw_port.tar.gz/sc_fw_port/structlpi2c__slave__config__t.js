var structlpi2c__slave__config__t =
[
    [ "enableSlave", "structlpi2c__slave__config__t.html#ad220cfa81b4117fd1d952b43ff0d5511", null ],
    [ "address0", "structlpi2c__slave__config__t.html#a16f171990f815872142d3fe73eb74ff4", null ],
    [ "address1", "structlpi2c__slave__config__t.html#afb3035cd87a9746bdbe5c6618a492034", null ],
    [ "addressMatchMode", "structlpi2c__slave__config__t.html#a1dc82ff6416b69128c0d6d78d533b093", null ],
    [ "filterDozeEnable", "structlpi2c__slave__config__t.html#a4cbbafe55351cb52d25b3de1a71e2231", null ],
    [ "filterEnable", "structlpi2c__slave__config__t.html#a6fcca02d50a48b5a3a2923ea449316ce", null ],
    [ "enableGeneralCall", "structlpi2c__slave__config__t.html#a061ed35a72d6e8ffe9a02be00f633f87", null ],
    [ "enableAck", "structlpi2c__slave__config__t.html#ab2cd4a19f68523031122851dd0ab1386", null ],
    [ "enableTx", "structlpi2c__slave__config__t.html#ad0fea92e29e7afff3d7072ab3c722bc8", null ],
    [ "enableRx", "structlpi2c__slave__config__t.html#aff856d2084ff0ede49f0ff25e6cf5529", null ],
    [ "enableAddress", "structlpi2c__slave__config__t.html#a6ec794389bd9fb5e51c802bb0b9ee26b", null ],
    [ "sclStall", "structlpi2c__slave__config__t.html#aa9b8ee0933df72c554862cdd9622dafd", null ],
    [ "ignoreAck", "structlpi2c__slave__config__t.html#ae68493537f90f7bff4a421ff534fb7a1", null ],
    [ "enableReceivedAddressRead", "structlpi2c__slave__config__t.html#ac273a825233fe937aa16d98e38664812", null ],
    [ "sdaGlitchFilterWidth_ns", "structlpi2c__slave__config__t.html#a7c28ef56af23d2e059942e8d80e5cd15", null ],
    [ "sclGlitchFilterWidth_ns", "structlpi2c__slave__config__t.html#a793ea7dd26bfb1f68daae2523e70d5a5", null ],
    [ "dataValidDelay_ns", "structlpi2c__slave__config__t.html#a920288e7667b3b363f019384ebc58606", null ],
    [ "clockHoldTime_ns", "structlpi2c__slave__config__t.html#a2e672f5446e7d86eb9d74bdc785df0fb", null ]
];