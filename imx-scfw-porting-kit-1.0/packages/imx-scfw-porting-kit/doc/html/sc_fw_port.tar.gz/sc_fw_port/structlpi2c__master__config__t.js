var structlpi2c__master__config__t =
[
    [ "enableMaster", "structlpi2c__master__config__t.html#a36f58debd82d2fe56bffc3d8d8748e22", null ],
    [ "enableDoze", "structlpi2c__master__config__t.html#a4f75d18b353af3668e0c3a8dc2c65133", null ],
    [ "debugEnable", "structlpi2c__master__config__t.html#a73c9f8dca26ed429fb5df6eebbb757b1", null ],
    [ "ignoreAck", "structlpi2c__master__config__t.html#af66e69bf2cf504a3f420774a2ee3456b", null ],
    [ "pinConfig", "structlpi2c__master__config__t.html#abf68fadb2fd229f0fd034e1961935ee4", null ],
    [ "baudRate_Hz", "structlpi2c__master__config__t.html#a2f8d353d1e637b082ad8ebe978a4d6b9", null ],
    [ "busIdleTimeout_ns", "structlpi2c__master__config__t.html#a936409ced864d404b3fdf0f66144ccd9", null ],
    [ "pinLowTimeout_ns", "structlpi2c__master__config__t.html#aa7788a850bf2ff954320368b237221ee", null ],
    [ "sdaGlitchFilterWidth_ns", "structlpi2c__master__config__t.html#a6b20d7345badb866950662d13177f137", null ],
    [ "sclGlitchFilterWidth_ns", "structlpi2c__master__config__t.html#abec5caf29a17c3cd3480e5b1b07f742a", null ],
    [ "enable", "structlpi2c__master__config__t.html#adf43f53aece30b66a9dc29a6fe2bb02d", null ],
    [ "source", "structlpi2c__master__config__t.html#a2c56d9865a4d122894a4918b21540151", null ],
    [ "polarity", "structlpi2c__master__config__t.html#acb38f33f1c5f33595cae1133882c4d24", null ],
    [ "hostRequest", "structlpi2c__master__config__t.html#a3eda1e27095c82f857c832ed7055d7cc", null ]
];