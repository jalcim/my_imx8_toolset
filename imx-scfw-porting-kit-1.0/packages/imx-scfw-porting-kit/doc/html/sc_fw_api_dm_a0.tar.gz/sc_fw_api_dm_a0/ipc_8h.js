var ipc_8h =
[
    [ "sc_ipc_open", "ipc_8h.html#abb2f4b630c85215940fa2e625d4bcef7", null ],
    [ "sc_ipc_close", "ipc_8h.html#a09416b858ec476f82ca5a06b9206a02f", null ],
    [ "sc_ipc_read", "ipc_8h.html#a791a9fe4feabeb8c68694d70e3e182eb", null ],
    [ "sc_ipc_write", "ipc_8h.html#ad0f8d3928b54e070f59e0213e1260635", null ]
];