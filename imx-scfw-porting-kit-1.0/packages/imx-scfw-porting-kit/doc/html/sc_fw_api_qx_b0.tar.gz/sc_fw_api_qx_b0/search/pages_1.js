var searchData=
[
  ['disclaimer',['Disclaimer',['../DISCLAIMER.html',1,'']]]
];
