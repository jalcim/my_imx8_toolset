var searchData=
[
  ['clock_20list',['Clock List',['../CLOCKS.html',1,'']]],
  ['control_20list',['Control List',['../CONTROLS.html',1,'']]]
];
