var modules =
[
    [ "(SVC) Pad Service", "group__PAD__SVC.html", "group__PAD__SVC" ],
    [ "(SVC) Timer Service", "group__TIMER__SVC.html", "group__TIMER__SVC" ],
    [ "(SVC) Power Management Service", "group__PM__SVC.html", "group__PM__SVC" ],
    [ "(SVC) Interrupt Service", "group__IRQ__SVC.html", "group__IRQ__SVC" ],
    [ "(SVC) Miscellaneous Service", "group__MISC__SVC.html", "group__MISC__SVC" ],
    [ "(SVC) Resource Management Service", "group__RM__SVC.html", "group__RM__SVC" ]
];