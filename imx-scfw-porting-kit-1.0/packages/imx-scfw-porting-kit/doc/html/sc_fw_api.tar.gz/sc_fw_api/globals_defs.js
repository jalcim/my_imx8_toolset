var globals_defs =
[
    [ "s", "globals_defs.html", null ]
];