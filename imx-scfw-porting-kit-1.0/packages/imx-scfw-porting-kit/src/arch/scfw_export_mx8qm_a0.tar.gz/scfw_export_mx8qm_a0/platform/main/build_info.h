#ifndef BUILD_INFO_H
#define BUILD_INFO_H

#define SCFW_BLD 2814

#define SCFW_BRANCH imx_4.14.62_1.0.0_beta

#define SCFW_BUILD (SCFW_BLD-0)
#define SCFW_COMMIT 0x006ff1979

#define SCFW_DATE "Nov 19 2018"
#define SCFW_DATE2 Nov_19_2018
#define SCFW_TIME "13:09:33"

#endif
