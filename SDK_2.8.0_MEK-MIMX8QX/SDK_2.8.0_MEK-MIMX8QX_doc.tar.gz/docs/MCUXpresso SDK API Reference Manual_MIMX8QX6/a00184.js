var a00184 =
[
    [ "SWO", "a00186.html", null ],
    [ "Semihosting", "a00185.html", null ],
    [ "DEBUGCONSOLE_REDIRECT_TO_TOOLCHAIN", "a00184.html#gabb8f0adbec02f143b4f84d2eb42126df", null ],
    [ "DEBUGCONSOLE_REDIRECT_TO_SDK", "a00184.html#gac33031f28afa29dc8fe1718bbc86ee23", null ],
    [ "DEBUGCONSOLE_DISABLE", "a00184.html#gaf8f85fd102e4aedcee3d061dc2d3e0c2", null ],
    [ "SDK_DEBUGCONSOLE", "a00184.html#ga7fdd594efdc8374ecd8684ed758d6cec", null ],
    [ "PRINTF", "a00184.html#gae1649fc947ca37a86917a08354f48d1a", null ],
    [ "printfCb", "a00184.html#gae9d851a9da87d7f21d8dd5a19f9eec7b", null ],
    [ "DbgConsole_Init", "a00184.html#ga12e50ee0450679fd8ca950a89338d366", null ],
    [ "DbgConsole_Deinit", "a00184.html#gad80e7aa70bbb3fce1a9168621372833e", null ],
    [ "DbgConsole_Printf", "a00184.html#ga1019139ac1c69fd62687250130c6ca7f", null ],
    [ "DbgConsole_Putchar", "a00184.html#gada572d86a06f028b5b1a5d0440f683e3", null ],
    [ "DbgConsole_Scanf", "a00184.html#ga6d87d10b03e4aaf8464206fe3829dd28", null ],
    [ "DbgConsole_Getchar", "a00184.html#ga11898c5015274863741c4f3f4d9edc08", null ],
    [ "DbgConsole_BlockingPrintf", "a00184.html#ga6a957577839a195b36adf2b6d9de1fd0", null ],
    [ "DbgConsole_Flush", "a00184.html#ga3194467c3dae6c5015b8b29c3cc1db1e", null ],
    [ "StrFormatPrintf", "a00184.html#ga50b9d66ac2ba38b23b99dac4e81f4b8c", null ],
    [ "StrFormatScanf", "a00184.html#gafe318e0fd8d0f6ebad0c8a871a7a196f", null ],
    [ "g_serialHandle", "a00184.html#gaad3c4240a1364156a239471ccdb9aa0b", null ]
];