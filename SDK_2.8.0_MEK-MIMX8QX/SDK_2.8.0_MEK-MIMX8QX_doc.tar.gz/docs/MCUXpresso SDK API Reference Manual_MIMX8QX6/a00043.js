var a00043 =
[
    [ "serial_port_swo_config_t", "a00043.html#a00316", [
      [ "clockRate", "a00043.html#a515e2f5ca8778fd65e10a0ac7f77d309", null ],
      [ "baudRate", "a00043.html#af06ab1ceb2156bba95ee5b125ef77e40", null ],
      [ "port", "a00043.html#aeab85500212c4b7945515d3acdf24aee", null ],
      [ "protocol", "a00043.html#a1fee1b1db63edc021f9b1d2e5808ecc0", null ]
    ] ],
    [ "SERIAL_PORT_SWO_HANDLE_SIZE", "a00043.html#ga65f815f28e5af3d42712ebefdd8662dc", null ],
    [ "serial_port_swo_protocol_t", "a00043.html#gab72244db50e88efd6d079d157558932d", [
      [ "kSerialManager_SwoProtocolManchester", "a00043.html#ggab72244db50e88efd6d079d157558932da57feeffbb98d786af19111f49bd6d733", null ],
      [ "kSerialManager_SwoProtocolNrz", "a00043.html#ggab72244db50e88efd6d079d157558932da1178f82728f1b7f27f28af46f8550d95", null ]
    ] ]
];