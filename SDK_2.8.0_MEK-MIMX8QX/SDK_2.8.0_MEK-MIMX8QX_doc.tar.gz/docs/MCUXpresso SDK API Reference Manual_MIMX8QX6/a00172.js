var a00172 =
[
    [ "LPSPI CMSIS Driver", "a00174.html", null ],
    [ "LPSPI FreeRTOS Driver", "a00173.html", "a00173" ],
    [ "LPSPI Peripheral driver", "a00032.html", "a00032" ],
    [ "LPSPI eDMA Driver", "a00033.html", "a00033" ]
];