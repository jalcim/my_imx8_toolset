var a00188 =
[
    [ "HAL_CODEC_HANDLER_SIZE", "a00188.html#gabcc76de089dc2c9415a9c9d1df7f1d8e", null ],
    [ "_codec_type", "a00188.html#gab04db8cf1054dbe730016a5e3ddc3aef", [
      [ "kCODEC_CS42888", "a00189.html#ggab04db8cf1054dbe730016a5e3ddc3aefae667850df8261ea1e8c02201e1ccafee", null ],
      [ "kCODEC_WM8904", "a00189.html#ggab04db8cf1054dbe730016a5e3ddc3aefacb2ee31cd4ee06712e3cf445e12cb389", null ],
      [ "kCODEC_WM8960", "a00189.html#ggab04db8cf1054dbe730016a5e3ddc3aefaa15237d33f0b971a6596458ef7aa8d99", null ],
      [ "kCODEC_WM8524", "a00189.html#ggab04db8cf1054dbe730016a5e3ddc3aefa57b2941cff245c37272e1ea4598c3ab0", null ],
      [ "kCODEC_SGTL5000", "a00189.html#ggab04db8cf1054dbe730016a5e3ddc3aefa870028cfe305a220c90a187029ae3408", null ],
      [ "kCODEC_DA7212", "a00189.html#ggab04db8cf1054dbe730016a5e3ddc3aefa533359b62306ff77d6cd4a6aeaf075ab", null ],
      [ "kCODEC_CS42888", "a00189.html#ggab04db8cf1054dbe730016a5e3ddc3aefae667850df8261ea1e8c02201e1ccafee", null ],
      [ "kCODEC_AK4497", "a00189.html#ggab04db8cf1054dbe730016a5e3ddc3aefa58d64d2b7b432eb8ede4e22a811cadf1", null ],
      [ "kCODEC_AK4458", "a00189.html#ggab04db8cf1054dbe730016a5e3ddc3aefa67f0293553ad8cc4bbb432b6b09f6900", null ],
      [ "kCODEC_TFA9XXX", "a00189.html#ggab04db8cf1054dbe730016a5e3ddc3aefa448b697ab0cc0c28740e77484faad04f", null ],
      [ "kCODEC_TFA9896", "a00189.html#ggab04db8cf1054dbe730016a5e3ddc3aefa899f42fede26bf5fd37ea863fb4e5624", null ],
      [ "kCODEC_WM8960", "a00189.html#ggab04db8cf1054dbe730016a5e3ddc3aefaa15237d33f0b971a6596458ef7aa8d99", null ]
    ] ],
    [ "HAL_CODEC_Init", "a00188.html#gaacaca021f47a8174ea25b69f8fceff5f", null ],
    [ "HAL_CODEC_Deinit", "a00188.html#ga6385e5d828698f51a25a741865cca2b2", null ],
    [ "HAL_CODEC_SetFormat", "a00188.html#gaabd166855f5c09d66f1c5c3d379a635d", null ],
    [ "HAL_CODEC_SetVolume", "a00188.html#ga51abed9ee2f12e9deecc772ec5d48ab5", null ],
    [ "HAL_CODEC_SetMute", "a00188.html#ga7fe3089ce2bacf817634df308f2a19e5", null ],
    [ "HAL_CODEC_SetPower", "a00188.html#gae3e89b179a83526dfaa69b0c4a665b77", null ],
    [ "HAL_CODEC_SetRecord", "a00188.html#gac22308d0062c5f138f52c2538e34319b", null ],
    [ "HAL_CODEC_SetRecordChannel", "a00188.html#gaaff43aee0fe7a998631c7ab79f44b1c7", null ],
    [ "HAL_CODEC_SetPlay", "a00188.html#gac1a980fbd520ed672bfa6d4cdb6037d1", null ],
    [ "HAL_CODEC_ModuleControl", "a00188.html#gab9b1d4ab9fd26f43be6d47ca575a3d0c", null ]
];