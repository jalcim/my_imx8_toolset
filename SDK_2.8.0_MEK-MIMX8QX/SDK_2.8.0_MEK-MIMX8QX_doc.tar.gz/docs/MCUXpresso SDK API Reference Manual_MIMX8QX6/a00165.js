var a00165 =
[
    [ "DPU_IRQSTEER_EnableInterrupt", "a00165.html#ga97030f44690a0dc8bcfb109cb9362d42", null ],
    [ "DPU_IRQSTEER_DisableInterrupt", "a00165.html#ga15ba7eb58f0517a6cc867e05d3263cc6", null ],
    [ "DPU_IRQSTEER_IsInterruptSet", "a00165.html#gafe905a3c9e7059e70540b54684a91b96", null ]
];