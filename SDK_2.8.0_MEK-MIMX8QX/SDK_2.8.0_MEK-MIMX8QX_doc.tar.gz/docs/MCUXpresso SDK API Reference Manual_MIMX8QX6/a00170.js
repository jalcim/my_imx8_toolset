var a00170 =
[
    [ "FSL_LPI2C_FREERTOS_DRIVER_VERSION", "a00170.html#gabe1b685d26560cdb8a3eccf81d013a3f", null ],
    [ "LPI2C_RTOS_Init", "a00170.html#ga537a8859c9c83c8a8ccf6e0188cc8b5c", null ],
    [ "LPI2C_RTOS_Deinit", "a00170.html#gacacb0612bfdcd7913be1cef8ad19fb9c", null ],
    [ "LPI2C_RTOS_Transfer", "a00170.html#gab5359e4f864d7f21eebcab8d3229e963", null ]
];