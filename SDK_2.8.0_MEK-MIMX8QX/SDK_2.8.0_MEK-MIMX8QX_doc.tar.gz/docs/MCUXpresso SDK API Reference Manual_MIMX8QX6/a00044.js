var a00044 =
[
    [ "serial_port_uart_config_t", "a00044.html#a00317", [
      [ "clockRate", "a00044.html#aaee9f6538c8d44e35c9990fe03dadc67", null ],
      [ "baudRate", "a00044.html#a0da7063e2b9390dadc60c41132fe268f", null ],
      [ "parityMode", "a00044.html#a8eb429b6d2a97008e31ec5041e152770", null ],
      [ "stopBitCount", "a00044.html#a95a9a17e85a994ec7ce086c72bc6a595", null ],
      [ "instance", "a00044.html#a94849d613b8264fe638179d2bcac4696", null ],
      [ "enableRx", "a00044.html#aadcfb6bef4a01d5acb2caae508d1194d", null ],
      [ "enableTx", "a00044.html#aff2edc56553434159080cc0e0040b135", null ]
    ] ],
    [ "SERIAL_PORT_UART_HANDLE_SIZE", "a00044.html#ga2109c092d5f72ef7729b0454b40e892f", null ],
    [ "serial_port_uart_parity_mode_t", "a00044.html#ga89a4bbed0c24cfe5e085194add680ccc", [
      [ "kSerialManager_UartParityDisabled", "a00044.html#gga89a4bbed0c24cfe5e085194add680ccca208958aa923a2c50ac1192a5085ab8b1", null ],
      [ "kSerialManager_UartParityEven", "a00044.html#gga89a4bbed0c24cfe5e085194add680ccca7d9d6f05fb6e1099fdfbf1f79a699356", null ],
      [ "kSerialManager_UartParityOdd", "a00044.html#gga89a4bbed0c24cfe5e085194add680ccca15bc11791c1f07fac71c808d083515db", null ]
    ] ],
    [ "serial_port_uart_stop_bit_count_t", "a00044.html#ga8bdf0213026f54fd54c21971e07f2d56", [
      [ "kSerialManager_UartOneStopBit", "a00044.html#gga8bdf0213026f54fd54c21971e07f2d56a5caed34146b357a7061aaacfe378e039", null ],
      [ "kSerialManager_UartTwoStopBit", "a00044.html#gga8bdf0213026f54fd54c21971e07f2d56a83eb7aee91f3fd8964d283c0057880dc", null ]
    ] ]
];