var searchData=
[
  ['dsi_5fcallback_5ft',['dsi_callback_t',['../a00014.html#ga5e70c4a718e5e14453e7afea0754b91e',1,'fsl_mipi_dsi.h']]]
];
