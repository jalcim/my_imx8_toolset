var searchData=
[
  ['vbp',['vbp',['../a00013.html#a9dcaef4d22aaac1996455be3abca0339',1,'dpu_display_timing_config_t::vbp()'],['../a00014.html#a26359e9ae0028a971dc6a48430c9655e',1,'dsi_dpi_config_t::vbp()']]],
  ['vfp',['vfp',['../a00013.html#a5da95b2e6644edc2d20add14cd27fee9',1,'dpu_display_timing_config_t::vfp()'],['../a00014.html#ab15a4ea1f0ee6b011eae8f4b613dd9dd',1,'dsi_dpi_config_t::vfp()']]],
  ['videomode',['videoMode',['../a00014.html#af5421373fe2f019a9c2593c92d58f87c',1,'dsi_dpi_config_t']]],
  ['virtualchannel',['virtualChannel',['../a00014.html#aed7f73cea1dd587c4f4bcd47d8e1d988',1,'dsi_dpi_config_t::virtualChannel()'],['../a00014.html#a93aa7b6fa356becffcf5112514d47cf4',1,'dsi_transfer_t::virtualChannel()']]],
  ['vsw',['vsw',['../a00013.html#a60ae1912b5e3405ccb37152050311bf0',1,'dpu_display_timing_config_t']]]
];
