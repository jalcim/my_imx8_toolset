var searchData=
[
  ['nbytes',['NBYTES',['../a00015.html#ada2a3af3cbf20ed38a3669c963d49f7d',1,'edma_tcd_t::NBYTES()'],['../a00018.html#aa2455ab188ee49df039e179809b3258d',1,'_esai_edma_handle::nbytes()'],['../a00029.html#a71e19bdaa2d6ed8e95d4b25497a45149',1,'_lpi2c_master_edma_handle::nbytes()'],['../a00033.html#a6cb0ef8b643f0c8da471897277a79e11',1,'_lpspi_master_edma_handle::nbytes()'],['../a00033.html#ac4304fd510994667fcc72cf37ef1345a',1,'_lpspi_slave_edma_handle::nbytes()'],['../a00035.html#a7ffb3be259d932a6a9f7e86aed4cc790',1,'_lpuart_edma_handle::nbytes()'],['../a00041.html#a061d53e53af802d59eca8bc3171297ce',1,'sai_edma_handle::nbytes()']]],
  ['neutralborderleftpixels',['neutralBorderLeftPixels',['../a00013.html#a1c9bbde3a5b9a7dd989a5e7629266a8e',1,'dpu_blit_blend_config_t']]],
  ['neutralbordermode',['neutralBorderMode',['../a00013.html#af01493d03f48f2eae1dd2295dcab4197',1,'dpu_blit_blend_config_t']]],
  ['neutralborderrightpixels',['neutralBorderRightPixels',['../a00013.html#a316cbb87cf58307abfa2f8e7df9340b5',1,'dpu_blit_blend_config_t']]],
  ['nextchanedgemode',['nextChanEdgeMode',['../a00022.html#af64561d78c1d94a7d7106785dce6da7c',1,'ftm_dual_edge_capture_param_t::nextChanEdgeMode()'],['../a00046.html#a700c20e23231ba39cf5413dde606d5fb',1,'tpm_dual_edge_capture_param_t::nextChanEdgeMode()']]],
  ['notifytype',['notifyType',['../a00037.html#a2ca3b1a52e315e072a8ab48fcc1dd62a',1,'notifier_notification_block_t']]],
  ['numextraeotp',['numExtraEoTp',['../a00014.html#afdfb5efd42812bc38658f6acf96bed41',1,'dsi_config_t']]],
  ['numlanes',['numLanes',['../a00014.html#a2bba59ba008f5464da3d5c576c57d98d',1,'dsi_config_t']]]
];
