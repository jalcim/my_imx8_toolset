var searchData=
[
  ['gpio_5fpin_5fconfig_5ft',['gpio_pin_config_t',['../a00023.html#a00276',1,'']]],
  ['gpt_5fconfig_5ft',['gpt_config_t',['../a00024.html#a00277',1,'']]]
];
