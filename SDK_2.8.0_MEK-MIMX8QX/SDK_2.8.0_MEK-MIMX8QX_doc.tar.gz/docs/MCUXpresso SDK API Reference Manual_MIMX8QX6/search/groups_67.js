var searchData=
[
  ['gpio_3a_20general_2dpurpose_20input_2foutput_20driver',['GPIO: General-Purpose Input/Output Driver',['../a00023.html',1,'']]],
  ['gpt_3a_20general_20purpose_20timer',['GPT: General Purpose Timer',['../a00024.html',1,'']]]
];
