var searchData=
[
  ['debug_20console',['Debug Console',['../a00184.html',1,'']]],
  ['dpr_3a_20display_20prefetch_20resolve',['DPR: Display Prefetch Resolve',['../a00012.html',1,'']]],
  ['display_20processing_20unit_20_28dpu_29',['Display Processing Unit (DPU)',['../a00013.html',1,'']]],
  ['dpu_20irqsteer_3a_20interrupt_20request_20steering_20driver',['DPU IRQSTEER: Interrupt Request Steering Driver',['../a00165.html',1,'']]]
];
