var searchData=
[
  ['xfer',['xfer',['../a00014.html#a4765b97f201d6886e992236d2fdc6bc7',1,'_dsi_handle']]]
];
