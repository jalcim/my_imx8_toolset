var a00038 =
[
    [ "prg_buffer_config_t", "a00038.html#a00303", [
      [ "width", "a00038.html#a5befca7f8d1979c504a7431542d853ef", null ],
      [ "height", "a00038.html#a6b0906146876170fc4b6e22a2335477d", null ],
      [ "strideBytes", "a00038.html#a5ccde895d1936908eb888d66df72776d", null ],
      [ "dataType", "a00038.html#a16fac49a4c20ee87362d32528dc5ecf3", null ]
    ] ],
    [ "FSL_PRG_DRIVER_VERSION", "a00038.html#ga7c5a2f0bba4ecd57426e86abcada1670", null ],
    [ "prg_data_type_t", "a00038.html#gac962526b4f70ecd940f1684573e01a6f", [
      [ "kPRG_DataType32Bpp", "a00038.html#ggac962526b4f70ecd940f1684573e01a6fa512feb2d9028cb51e029f23e8094c517", null ],
      [ "kPRG_DataType24Bpp", "a00038.html#ggac962526b4f70ecd940f1684573e01a6fa0cbf2de061611876fabad13eb682f5b7", null ],
      [ "kPRG_DataType16Bpp", "a00038.html#ggac962526b4f70ecd940f1684573e01a6fa0da2cfefc504981aa8c2c1bb5b6f5c26", null ],
      [ "kPRG_DataType8Bpp", "a00038.html#ggac962526b4f70ecd940f1684573e01a6fa13827971910947f3aadda23243cd102d", null ]
    ] ],
    [ "PRG_Init", "a00038.html#gaccf61c59e86e6a8eb151062962ecc0b1", null ],
    [ "PRG_Deinit", "a00038.html#ga10b5dc9c6b097862a2220f773c8e1acb", null ],
    [ "PRG_Enable", "a00038.html#gad580516dbeead6f1930d083d0d0fb5dc", null ],
    [ "PRG_EnableShadowLoad", "a00038.html#ga6238ab31219127a10bab7384224f41d9", null ],
    [ "PRG_UpdateRegister", "a00038.html#ga1b131bff262b1787e9df4364464b4729", null ],
    [ "PRG_SetBufferConfig", "a00038.html#ga3be1b5c3a7ede2bfd0f8ae8f95667f6a", null ],
    [ "PRG_BufferGetDefaultConfig", "a00038.html#gaa2f53d38eac22a310f7f32ad9b64caac", null ],
    [ "PRG_SetBufferAddr", "a00038.html#gab1b6906ae5cd2ee8280160c07204b698", null ]
];