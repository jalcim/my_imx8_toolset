var a00048 =
[
    [ "wm8960 adapter", "a00189.html", "a00189" ],
    [ "wm8960_audio_format_t", "a00048.html#a00325", [
      [ "mclk_HZ", "a00048.html#afb1efbb406e368e6fd5393da2543bb8a", null ],
      [ "sampleRate", "a00048.html#ae96a0158b6a005c24d4713578b9f493a", null ],
      [ "bitWidth", "a00048.html#abd1d53b78beb2d929a1d1200c2a18227", null ]
    ] ],
    [ "wm8960_config_t", "a00048.html#a00326", [
      [ "route", "a00048.html#aecb1d7a00e01dca75ed9008045fea7c9", null ],
      [ "bus", "a00048.html#a2aa9a1534286c670f9cccc121dfc2427", null ],
      [ "format", "a00048.html#a1f604d76836bba22c48628d1790abbf1", null ],
      [ "master_slave", "a00048.html#a2628e48b064d8d943c0f247da6404342", null ],
      [ "enableSpeaker", "a00048.html#ab417dfff6b9fbaed35eb25d8b3d77bc2", null ],
      [ "leftInputSource", "a00048.html#a775a0be4401bb4e3bfabc2cf30bc62c6", null ],
      [ "rightInputSource", "a00048.html#a4e52782271640121f001ba4d1404e5e3", null ],
      [ "playSource", "a00048.html#a7c121144634e1ef8a1eed7f28f155031", null ],
      [ "slaveAddress", "a00048.html#a3789a7dad901df8d576de42d76b47b41", null ],
      [ "i2cConfig", "a00048.html#a223e757e0c4efc169f0b45385d99dbd5", null ]
    ] ],
    [ "wm8960_handle_t", "a00048.html#a00327", [
      [ "config", "a00048.html#a1445b9b877b692662e5fb0f8ce3224c9", null ],
      [ "i2cHandle", "a00048.html#ae6d5faabcff6b852ebb460da190c9811", null ]
    ] ],
    [ "FSL_WM8960_DRIVER_VERSION", "a00048.html#ga4a96a53318ae1b2c8778b10501018fc3", null ],
    [ "WM8960_I2C_HANDLER_SIZE", "a00048.html#gad42c885e755bfa53b74cd811af45db8a", null ],
    [ "WM8960_LINVOL", "a00048.html#gae6c6a3b67c7930937dd877390dc94cbe", null ],
    [ "WM8960_CACHEREGNUM", "a00048.html#gacdd9105c1955cf9b7be99a89121e9e7a", null ],
    [ "WM8960_IFACE1_FORMAT_MASK", "a00048.html#ga1cfddde9bff2839d98dad8cea4d958df", null ],
    [ "WM8960_IFACE1_WL_MASK", "a00048.html#ga5d2bc2d14ee9c5aeb37042af35715e1b", null ],
    [ "WM8960_IFACE1_LRP_MASK", "a00048.html#ga17766c78737e1eb92290921c3110dd92", null ],
    [ "WM8960_IFACE1_DLRSWAP_MASK", "a00048.html#gaa36fdca87c244c8f6d2fff4d96611087", null ],
    [ "WM8960_IFACE1_MS_MASK", "a00048.html#ga139e7ba937dd4d9cf1077bf1598ec86b", null ],
    [ "WM8960_IFACE1_BCLKINV_MASK", "a00048.html#gacb30f80634350ca28097b895df43cc02", null ],
    [ "WM8960_IFACE1_ALRSWAP_MASK", "a00048.html#ga5b6f652b9b3e5fd2dc7d728f7b967c9a", null ],
    [ "WM8960_POWER1_VREF_MASK", "a00048.html#ga885a20098e84dc26ab843b69830048b5", null ],
    [ "WM8960_POWER2_DACL_MASK", "a00048.html#gab8a3493e9e8f10ae4d2c7986aa0c3329", null ],
    [ "WM8960_I2C_ADDR", "a00048.html#gab3675ad227d4528542916e9b591ace43", null ],
    [ "WM8960_I2C_BAUDRATE", "a00048.html#gaf9f86ecdf51d7c84a55caa0ef67a37f5", null ],
    [ "wm8960_module_t", "a00048.html#gad71999d652d6d29485aea6dacf371fc7", [
      [ "kWM8960_ModuleADC", "a00048.html#ggad71999d652d6d29485aea6dacf371fc7ae06d8a84878c6ea432e3401e65fb87cb", null ],
      [ "kWM8960_ModuleDAC", "a00048.html#ggad71999d652d6d29485aea6dacf371fc7a536f29cc4bde51273aee16ca2f5e6079", null ],
      [ "kWM8960_ModuleVREF", "a00048.html#ggad71999d652d6d29485aea6dacf371fc7a73f24782244c9b2965072eaa7e59a5d3", null ],
      [ "kWM8960_ModuleHP", "a00048.html#ggad71999d652d6d29485aea6dacf371fc7ac5579774be5b12a7a18f98d1cf374c55", null ],
      [ "kWM8960_ModuleMICB", "a00048.html#ggad71999d652d6d29485aea6dacf371fc7a4db03d48e615c4643ad53e361737218d", null ],
      [ "kWM8960_ModuleMIC", "a00048.html#ggad71999d652d6d29485aea6dacf371fc7a2ccb86eb6c7ce514a7ce51b97206c426", null ],
      [ "kWM8960_ModuleLineIn", "a00048.html#ggad71999d652d6d29485aea6dacf371fc7a303a97aa3ca809c7f6a972d64287a878", null ],
      [ "kWM8960_ModuleLineOut", "a00048.html#ggad71999d652d6d29485aea6dacf371fc7afee92d11ea3a0fc6f9345eac1c648215", null ],
      [ "kWM8960_ModuleSpeaker", "a00048.html#ggad71999d652d6d29485aea6dacf371fc7ab2927284f295d943ba601829f5c85d25", null ],
      [ "kWM8960_ModuleOMIX", "a00048.html#ggad71999d652d6d29485aea6dacf371fc7a0bedf71e89a9a96bf649200db84f77be", null ]
    ] ],
    [ "_wm8960_play_channel", "a00048.html#gacd8626f8ca4a816e87d0014704b2c66c", [
      [ "kWM8960_HeadphoneLeft", "a00048.html#ggacd8626f8ca4a816e87d0014704b2c66ca5cb5a5fd1015f7957c198a440d406e96", null ],
      [ "kWM8960_HeadphoneRight", "a00048.html#ggacd8626f8ca4a816e87d0014704b2c66ca0721220fe5946056318d7e0ec3cbb682", null ],
      [ "kWM8960_SpeakerLeft", "a00048.html#ggacd8626f8ca4a816e87d0014704b2c66ca38ea4c658535deb51658ce2e00aa4c3e", null ],
      [ "kWM8960_SpeakerRight", "a00048.html#ggacd8626f8ca4a816e87d0014704b2c66ca12ce651420aecbccd5be4512ab204523", null ]
    ] ],
    [ "wm8960_play_source_t", "a00048.html#gac536addc1967c512191ce08e3452e84a", [
      [ "kWM8960_PlaySourcePGA", "a00048.html#ggac536addc1967c512191ce08e3452e84aa861dc114e341d3245bed939058c16183", null ],
      [ "kWM8960_PlaySourceInput", "a00048.html#ggac536addc1967c512191ce08e3452e84aaac489a1eedbfc272a9023862efedacc0", null ],
      [ "kWM8960_PlaySourceDAC", "a00048.html#ggac536addc1967c512191ce08e3452e84aa5a1779ecd2781e184cbb41aa826f9550", null ]
    ] ],
    [ "wm8960_route_t", "a00048.html#gadeeac537e163e7225244411c27a43210", [
      [ "kWM8960_RouteBypass", "a00048.html#ggadeeac537e163e7225244411c27a43210a7ebcfe6753412e27508fab055a844642", null ],
      [ "kWM8960_RoutePlayback", "a00048.html#ggadeeac537e163e7225244411c27a43210a952a2f8b6834cb61b67f6430a71094ef", null ],
      [ "kWM8960_RoutePlaybackandRecord", "a00048.html#ggadeeac537e163e7225244411c27a43210a6a5973f3f8f53223a26f9e1368eae9c9", null ],
      [ "kWM8960_RouteRecord", "a00048.html#ggadeeac537e163e7225244411c27a43210a6d7f4a4f100efb3ad5b05ba3eae74def", null ]
    ] ],
    [ "wm8960_protocol_t", "a00048.html#ga64f94347b02b08161996766de30b14fb", [
      [ "kWM8960_BusI2S", "a00048.html#gga64f94347b02b08161996766de30b14fba8efabaf43c6bb17acf54ae37cec6c5f5", null ],
      [ "kWM8960_BusLeftJustified", "a00048.html#gga64f94347b02b08161996766de30b14fbaf87b1ee7c9c54da5f136f1b79a64b5b9", null ],
      [ "kWM8960_BusRightJustified", "a00048.html#gga64f94347b02b08161996766de30b14fbaed00553ce02a48439a5ec8984d5db467", null ],
      [ "kWM8960_BusPCMA", "a00048.html#gga64f94347b02b08161996766de30b14fba8fb45995b3bf25ee5122e4ab270c7d2a", null ],
      [ "kWM8960_BusPCMB", "a00048.html#gga64f94347b02b08161996766de30b14fba7a6a94a2db557a1ebe08f4cf10b23f66", null ]
    ] ],
    [ "wm8960_input_t", "a00048.html#ga53d7560a3c263de4bdaddb7ff6b91a8a", [
      [ "kWM8960_InputClosed", "a00048.html#gga53d7560a3c263de4bdaddb7ff6b91a8aa2c6eae84feeba20a1b15e8538202bdbf", null ],
      [ "kWM8960_InputSingleEndedMic", "a00048.html#gga53d7560a3c263de4bdaddb7ff6b91a8aa1013bdcf916395fb0c7cda34bc9218df", null ],
      [ "kWM8960_InputDifferentialMicInput2", "a00048.html#gga53d7560a3c263de4bdaddb7ff6b91a8aa96dd0a1fbf73e530b2a8f73994fa8788", null ],
      [ "kWM8960_InputDifferentialMicInput3", "a00048.html#gga53d7560a3c263de4bdaddb7ff6b91a8aa26c5d1f279052c5b3991a563af490ae0", null ],
      [ "kWM8960_InputLineINPUT2", "a00048.html#gga53d7560a3c263de4bdaddb7ff6b91a8aafb03754cff21d67de95242a285a3fc13", null ],
      [ "kWM8960_InputLineINPUT3", "a00048.html#gga53d7560a3c263de4bdaddb7ff6b91a8aae011db846215196ebcecb8cbbb17e5e3", null ]
    ] ],
    [ "_wm8960_sample_rate", "a00048.html#gaeadc594e5d82dcc24817c5336f9c2645", [
      [ "kWM8960_AudioSampleRate8KHz", "a00048.html#ggaeadc594e5d82dcc24817c5336f9c2645a50961d3980d3e37dd41e3d8c62c3a870", null ],
      [ "kWM8960_AudioSampleRate11025Hz", "a00048.html#ggaeadc594e5d82dcc24817c5336f9c2645a509786e8390518009b7349ee35290f02", null ],
      [ "kWM8960_AudioSampleRate12KHz", "a00048.html#ggaeadc594e5d82dcc24817c5336f9c2645afc081d6675dcc61766d1db7b7a6e57ba", null ],
      [ "kWM8960_AudioSampleRate16KHz", "a00048.html#ggaeadc594e5d82dcc24817c5336f9c2645a37f98eb4cc147382a0001729bfcffd98", null ],
      [ "kWM8960_AudioSampleRate22050Hz", "a00048.html#ggaeadc594e5d82dcc24817c5336f9c2645a0a285edc0cb7ce46f6844fca3f8f3689", null ],
      [ "kWM8960_AudioSampleRate24KHz", "a00048.html#ggaeadc594e5d82dcc24817c5336f9c2645acc8ce4cd6fa286f26a8850093f2aa696", null ],
      [ "kWM8960_AudioSampleRate32KHz", "a00048.html#ggaeadc594e5d82dcc24817c5336f9c2645a59a22bfdc17d3ce83eb4d78507565700", null ],
      [ "kWM8960_AudioSampleRate44100Hz", "a00048.html#ggaeadc594e5d82dcc24817c5336f9c2645af44c5c0712d53f88943e56d8ccd466a4", null ],
      [ "kWM8960_AudioSampleRate48KHz", "a00048.html#ggaeadc594e5d82dcc24817c5336f9c2645ae09e315fe927817900e50edd8f5dc29c", null ],
      [ "kWM8960_AudioSampleRate96KHz", "a00048.html#ggaeadc594e5d82dcc24817c5336f9c2645a07ce8a1ae26763623e24caed8f9c42e3", null ],
      [ "kWM8960_AudioSampleRate192KHz", "a00048.html#ggaeadc594e5d82dcc24817c5336f9c2645ae9007085de5c77817b93a8d5ef16e227", null ],
      [ "kWM8960_AudioSampleRate384KHz", "a00048.html#ggaeadc594e5d82dcc24817c5336f9c2645abdd1e457644ed2ba495ab7c010876e9e", null ]
    ] ],
    [ "_wm8960_audio_bit_width", "a00048.html#ga3952eb59ea19020a8588b862a62d8a36", [
      [ "kWM8960_AudioBitWidth16bit", "a00048.html#gga3952eb59ea19020a8588b862a62d8a36a1e3149fabb02a0cc14413352945cabef", null ],
      [ "kWM8960_AudioBitWidth20bit", "a00048.html#gga3952eb59ea19020a8588b862a62d8a36ab67c78216a745b5cd0c6b2bc348a6d85", null ],
      [ "kWM8960_AudioBitWidth24bit", "a00048.html#gga3952eb59ea19020a8588b862a62d8a36a32e10ddc499b7b6c91af8a4b515fb9b3", null ],
      [ "kWM8960_AudioBitWidth32bit", "a00048.html#gga3952eb59ea19020a8588b862a62d8a36abd1253b6f3fa57dd356d1280add31a66", null ]
    ] ],
    [ "WM8960_Init", "a00048.html#ga4ef387deb1d3d093e110f5dda35d3caa", null ],
    [ "WM8960_Deinit", "a00048.html#gaedaaeb3e155069e1e7d6e41d8597561f", null ],
    [ "WM8960_SetDataRoute", "a00048.html#ga6922f6e4b7e5edec6f29549e1f9df98b", null ],
    [ "WM8960_SetLeftInput", "a00048.html#gaf6b69e1ebbca5832f6c2c9065a8623e5", null ],
    [ "WM8960_SetRightInput", "a00048.html#ga78f5175195593c91559abd992e9cf395", null ],
    [ "WM8960_SetProtocol", "a00048.html#ga13e6e6f7bc58616cc9a79be31137ede5", null ],
    [ "WM8960_SetMasterSlave", "a00048.html#ga88842e10f2046b4bb6cd24f6e605ccad", null ],
    [ "WM8960_SetVolume", "a00048.html#ga046444c70f68c74b0514211a6f4ab3a7", null ],
    [ "WM8960_GetVolume", "a00048.html#ga57f8b8228a0031cccc8fba4c079ccd7b", null ],
    [ "WM8960_SetMute", "a00048.html#gafd5893a1845dfd1a4c1721f9cbf720e0", null ],
    [ "WM8960_SetModule", "a00048.html#gaa173f27a2ffcfc3d7c9fc60f96e1070f", null ],
    [ "WM8960_SetPlay", "a00048.html#gadd0a4568108064adc221bd9c823e423a", null ],
    [ "WM8960_ConfigDataFormat", "a00048.html#ga8ac24f4e16ca54145d44e38ac8085e6f", null ],
    [ "WM8960_SetJackDetect", "a00048.html#ga2bb7a2a1dfb0513f8e1238a952cc77cc", null ],
    [ "WM8960_WriteReg", "a00048.html#ga46c9a029f9e5155486506e4493fe983f", null ],
    [ "WM8960_ReadReg", "a00048.html#ga32914c3d6d76e5507f945966400229ca", null ],
    [ "WM8960_ModifyReg", "a00048.html#gab7aa751625c271e00860ab99b33a9532", null ]
];