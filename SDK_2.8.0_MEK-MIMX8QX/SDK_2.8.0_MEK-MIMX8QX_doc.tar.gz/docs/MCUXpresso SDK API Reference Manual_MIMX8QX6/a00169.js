var a00169 =
[
    [ "LPI2C CMSIS Driver", "a00171.html", null ],
    [ "LPI2C FreeRTOS Driver", "a00170.html", "a00170" ],
    [ "LPI2C Master DMA Driver", "a00029.html", "a00029" ],
    [ "LPI2C Master Driver", "a00028.html", "a00028" ],
    [ "LPI2C Slave Driver", "a00030.html", "a00030" ],
    [ "FSL_LPI2C_DRIVER_VERSION", "a00169.html#gad5469acd31ed336234c60b02cf7c424a", null ],
    [ "I2C_RETRY_TIMES", "a00169.html#gaac288786aaa7d0cb947c91591baf42d7", [
      [ "kStatus_LPI2C_Busy", "a00169.html#gga77867ab4129f63159b37bca3b652a798af52a270e301641b8855edf3fcc843814", null ],
      [ "kStatus_LPI2C_Idle", "a00169.html#gga77867ab4129f63159b37bca3b652a798a6603ec1135f58532c9d4accc3661bc27", null ],
      [ "kStatus_LPI2C_Nak", "a00169.html#gga77867ab4129f63159b37bca3b652a798a75dbc01ed590c24e787fadb97ba2f684", null ],
      [ "kStatus_LPI2C_FifoError", "a00169.html#gga77867ab4129f63159b37bca3b652a798a5b3634e1fedb0ad8cc38476aac29477e", null ],
      [ "kStatus_LPI2C_BitError", "a00169.html#gga77867ab4129f63159b37bca3b652a798aa08b2b2938831610ff303e2415291be6", null ],
      [ "kStatus_LPI2C_ArbitrationLost", "a00169.html#gga77867ab4129f63159b37bca3b652a798a5169d7e655df8bde3b4fc6d49ae8777a", null ],
      [ "kStatus_LPI2C_PinLowTimeout", "a00169.html#gga77867ab4129f63159b37bca3b652a798aa8c558fc024cbde751d7861ea6efca78", null ],
      [ "kStatus_LPI2C_NoTransferInProgress", "a00169.html#gga77867ab4129f63159b37bca3b652a798aa301f3640e63a3d3d951429b9b7ee866", null ],
      [ "kStatus_LPI2C_DmaRequestFail", "a00169.html#gga77867ab4129f63159b37bca3b652a798a14d70db977f150497fd4a9d232dc2cd8", null ],
      [ "kStatus_LPI2C_Timeout", "a00169.html#gga77867ab4129f63159b37bca3b652a798a002394fe77437f41ea82506d69646d66", null ]
    ] ]
];