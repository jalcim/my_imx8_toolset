var a00161 =
[
    [ "FSL_ASMC_DRIVER_VERSION", "a00161.html#ga32f99fa91ba6973977a609fe567c6fec", null ],
    [ "_asmc_system_reset_status_flags", "a00161.html#ga509a8e56e626930ec8b53d0193e6c7ce", [
      [ "kASMC_LowLeakageWakeupResetFlag", "a00161.html#gga509a8e56e626930ec8b53d0193e6c7ceaf688b56358a6217872f93b9d46b24143", null ],
      [ "kASMC_WatchdogResetFlag", "a00161.html#gga509a8e56e626930ec8b53d0193e6c7cea89dd080e58107f2cd721354e4208c36e", null ],
      [ "kASMC_ChipResetNotPORFlag", "a00161.html#gga509a8e56e626930ec8b53d0193e6c7ceacbf5df257b1d465a57e00dc2b9e8f103", null ],
      [ "kASMC_PowerOnResetFlag", "a00161.html#gga509a8e56e626930ec8b53d0193e6c7ceae2d162055b8cfbee8391394d74b6b1da", null ],
      [ "kASMC_Core1LockupResetFlag", "a00161.html#gga509a8e56e626930ec8b53d0193e6c7cea647c25d0cc8a90355cf3924bc38ee971", null ],
      [ "kASMC_SoftwareResetFlag", "a00161.html#gga509a8e56e626930ec8b53d0193e6c7cea930062162ea1c5c7bdd8ce0ffae035d1", null ],
      [ "kASMC_StopModeAcknowledgeErrorResetFlag", "a00161.html#gga509a8e56e626930ec8b53d0193e6c7cea88539c4cc45a83dcd3ec25d329b27ceb", null ]
    ] ],
    [ "asmc_power_mode_protection_t", "a00161.html#gaab6ec5da85f81d65cc4cf3a98e2cb995", [
      [ "kASMC_AllowPowerModeVlls", "a00161.html#ggaab6ec5da85f81d65cc4cf3a98e2cb995ad30fa27403d78accba2b9d172ab10d09", null ],
      [ "kASMC_AllowPowerModeLls", "a00161.html#ggaab6ec5da85f81d65cc4cf3a98e2cb995a2280b548f8c224f242f565f9789eebe6", null ],
      [ "kASMC_AllowPowerModeVlp", "a00161.html#ggaab6ec5da85f81d65cc4cf3a98e2cb995aa9d10f89bbad2fc454f70eb8235fbf20", null ],
      [ "kASMC_AllowPowerModeAll", "a00161.html#ggaab6ec5da85f81d65cc4cf3a98e2cb995a49889e0250f31a55c562351957196086", null ]
    ] ],
    [ "asmc_power_state_t", "a00161.html#ga1bbc79727900000505cbc473dab1b50e", [
      [ "kASMC_PowerStateRun", "a00161.html#gga1bbc79727900000505cbc473dab1b50ea0ea965a8bc9f375ce4efb8f92dcb68fb", null ],
      [ "kASMC_PowerStateStop", "a00161.html#gga1bbc79727900000505cbc473dab1b50eaf3eb086b1a93541bc4f481b76adb682b", null ],
      [ "kASMC_PowerStateVlpr", "a00161.html#gga1bbc79727900000505cbc473dab1b50ea5292aa16dd6760b62c7667131c2c2ebf", null ],
      [ "kASMC_PowerStateVlpw", "a00161.html#gga1bbc79727900000505cbc473dab1b50eae21b868f2392f502fa5eeede8665c224", null ],
      [ "kASMC_PowerStateVlps", "a00161.html#gga1bbc79727900000505cbc473dab1b50ea4cd70e0a708a296be4203be2acce8873", null ],
      [ "kASMC_PowerStateLls", "a00161.html#gga1bbc79727900000505cbc473dab1b50eab61df5ad6a58d216dc3e43ad5286b80b", null ],
      [ "kASMC_PowerStateVlls", "a00161.html#gga1bbc79727900000505cbc473dab1b50ea7fed1c5fd5fc5ce49c3f5e7232676daf", null ]
    ] ],
    [ "asmc_run_mode_t", "a00161.html#gad069d30a7d6279818ac86aa4eae554f0", [
      [ "kASMC_RunNormal", "a00161.html#ggad069d30a7d6279818ac86aa4eae554f0a6b3f469fdac931b91e242e654022d5f5", null ],
      [ "kASMC_RunVlpr", "a00161.html#ggad069d30a7d6279818ac86aa4eae554f0ad5b8fdefee33e9ad1266fcd4d5d1b487", null ]
    ] ],
    [ "asmc_stop_mode_t", "a00161.html#ga0cc0809e2db25e07233cf98d4c7e2282", [
      [ "kASMC_StopNormal", "a00161.html#gga0cc0809e2db25e07233cf98d4c7e2282aec8292d898f9229f0f1d6e9e47357ae0", null ],
      [ "kASMC_StopVlps", "a00161.html#gga0cc0809e2db25e07233cf98d4c7e2282a0572509bdf98df5ba269703727a9853c", null ],
      [ "kASMC_StopLls", "a00161.html#gga0cc0809e2db25e07233cf98d4c7e2282a8e7e918dca3d83312e80967371ec6971", null ],
      [ "kASMC_StopVlls", "a00161.html#gga0cc0809e2db25e07233cf98d4c7e2282aeef8bac621e563498a8670cf27d112dc", null ]
    ] ],
    [ "asmc_partial_stop_option_t", "a00161.html#ga3f917ae589bcb8f17d9e32b65b8c4849", [
      [ "kASMC_PartialStop", "a00161.html#gga3f917ae589bcb8f17d9e32b65b8c4849a5aae2695198446cde995be5dd20270c5", null ],
      [ "kASMC_PartialStop1", "a00161.html#gga3f917ae589bcb8f17d9e32b65b8c4849a46131f5059103c7b4fe43d03fa0cc7fc", null ],
      [ "kASMC_PartialStop2", "a00161.html#gga3f917ae589bcb8f17d9e32b65b8c4849ad9cc5ef09f95b1402d36e68a58242a8a", null ]
    ] ],
    [ "ASMC_GetSystemResetStatusFlags", "a00161.html#ga491db39c9852e45ec8479dd22ce6114f", null ],
    [ "ASMC_SetPowerModeProtection", "a00161.html#gaf7e868dad4bb998260f57e18e6f6d58d", null ],
    [ "ASMC_GetPowerModeState", "a00161.html#gace9d3b261ac1ecbfd1073ba18f5cf66a", null ],
    [ "ASMC_PreEnterStopModes", "a00161.html#ga643c95916820bb0c4dc7a3c1404c62dc", null ],
    [ "ASMC_PostExitStopModes", "a00161.html#ga0d694a0c7e04ec3e30864e3c14e1d128", null ],
    [ "ASMC_PreEnterWaitModes", "a00161.html#gaa11a26d031548c839265047448902aa6", null ],
    [ "ASMC_PostExitWaitModes", "a00161.html#ga610ad03e5260615d95f332c3feeab450", null ],
    [ "ASMC_SetPowerModeRun", "a00161.html#ga882aa0f9969ab2c1c797564122ddf8df", null ],
    [ "ASMC_SetPowerModeWait", "a00161.html#ga118375e7625ab55c4f0fb86eece81e02", null ],
    [ "ASMC_SetPowerModeStop", "a00161.html#ga71765fafb05ef4997bbf5773a795b3d2", null ],
    [ "ASMC_SetPowerModeVlpr", "a00161.html#ga04cef871153fe43f3792401eb9d2dc8b", null ],
    [ "ASMC_SetPowerModeVlpw", "a00161.html#gaaf471e03344eaef7c90cf65ea1c07134", null ],
    [ "ASMC_SetPowerModeVlps", "a00161.html#gaeab1bab3bc59dd2f607e96c71f338534", null ],
    [ "ASMC_SetPowerModeLls", "a00161.html#ga31d57e319d04ddf157d1415e99f9b3b7", null ],
    [ "ASMC_SetPowerModeVlls", "a00161.html#ga50172b349c99bae3d2bc8e04f248ffd7", null ]
];