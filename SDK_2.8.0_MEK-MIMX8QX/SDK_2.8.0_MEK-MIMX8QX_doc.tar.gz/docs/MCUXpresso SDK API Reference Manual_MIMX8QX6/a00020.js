var a00020 =
[
    [ "flexcan_edma_handle_t", "a00020.html#a00198", [
      [ "callback", "a00020.html#a63bbb14985ea667bb86d933782244ebe", null ],
      [ "userData", "a00020.html#a8408c788bc9497c7a74811940a28bce7", null ],
      [ "rxFifoEdmaHandle", "a00020.html#a923894ca8505812ac61ad5632677a7d2", null ],
      [ "rxFifoState", "a00020.html#af08257e6fde0f8f49d152ab07264dfd3", null ]
    ] ],
    [ "FSL_FLEXCAN_EDMA_DRIVER_VERSION", "a00020.html#ga3a725e7f5fd30ef8458220269fbea29f", null ],
    [ "flexcan_edma_transfer_callback_t", "a00020.html#ga200b7c77f4d5b5495193e58772e12c68", null ],
    [ "FLEXCAN_TransferCreateHandleEDMA", "a00020.html#ga1ca334397a0902a09b8b7ddd4a73d87b", null ],
    [ "FLEXCAN_PrepareTransfConfiguration", "a00020.html#ga5cedfaa95e88853c01d3d8d5b3161e3b", null ],
    [ "FLEXCAN_StartTransferDatafromRxFIFO", "a00020.html#ga7a883dbd4d8b2e57e9e04f69a281a8e1", null ],
    [ "FLEXCAN_TransferReceiveFifoEDMA", "a00020.html#gaf38af081946e9543788f45d3b85611b8", null ],
    [ "FLEXCAN_TransferAbortReceiveFifoEDMA", "a00020.html#ga518cce21e8dde19dc32b21a68c549b1b", null ]
];