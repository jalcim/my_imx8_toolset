var a00041 =
[
    [ "sai_edma_handle_t", "a00041.html#a00307", [
      [ "dmaHandle", "a00041.html#ac754f63e6faf24815240a7677eb4a908", null ],
      [ "nbytes", "a00041.html#a061d53e53af802d59eca8bc3171297ce", null ],
      [ "bytesPerFrame", "a00041.html#a999a7493ad74199568fa0ae9a1daba82", null ],
      [ "channel", "a00041.html#a2585391f7bbe7407bd405362ef9d9eb5", null ],
      [ "count", "a00041.html#a66e701d5eed6e4d80fbd8b042fb73fc3", null ],
      [ "state", "a00041.html#a6611961529129ff1165493033c5dc573", null ],
      [ "callback", "a00041.html#adde936fb4e2daa1753c841f3d52e2533", null ],
      [ "userData", "a00041.html#af8526618ff18f03496d39a9003a02d6a", null ],
      [ "tcd", "a00041.html#a6270bea65d16835b479649d9083bfddc", null ],
      [ "saiQueue", "a00041.html#a8d5ec64db292ea91cacf543c6fe4f22b", null ],
      [ "transferSize", "a00041.html#a28d0ac4b3b16fd68dfbb8ecf303397a3", null ],
      [ "queueUser", "a00041.html#a13a45007eebf06db42ed42bb83ee3dbd", null ],
      [ "queueDriver", "a00041.html#a969d922d9b8b82ac4fee2d9bb63b6a5a", null ]
    ] ],
    [ "FSL_SAI_EDMA_DRIVER_VERSION", "a00041.html#gadec154552382f7b68bce82ce829f3911", null ],
    [ "sai_edma_callback_t", "a00041.html#gaeb6ca21880d8cd8f5f954d38bfa73d63", null ],
    [ "SAI_TransferTxCreateHandleEDMA", "a00041.html#ga84f148e1d3fe186ce6604d637f89c2c1", null ],
    [ "SAI_TransferRxCreateHandleEDMA", "a00041.html#ga44a719a507630fdcc25ba93690098a89", null ],
    [ "SAI_TransferTxSetFormatEDMA", "a00041.html#ga78b693c7c4667056f74c4763f47c6e14", null ],
    [ "SAI_TransferRxSetFormatEDMA", "a00041.html#ga69b84d866cc9c5736780276c668df495", null ],
    [ "SAI_TransferTxSetConfigEDMA", "a00041.html#ga5295038a021787aef619bdd9f96981da", null ],
    [ "SAI_TransferRxSetConfigEDMA", "a00041.html#gaed5d72de0d0aa0ac71de3222924e4aa7", null ],
    [ "SAI_TransferSendEDMA", "a00041.html#ga7a2c125e1f975c9f718dcb820ac46f63", null ],
    [ "SAI_TransferReceiveEDMA", "a00041.html#ga9060fb028d5a24d8763066981b079900", null ],
    [ "SAI_TransferTerminateSendEDMA", "a00041.html#ga6b3db811719337e4f2172c66ceeb7933", null ],
    [ "SAI_TransferTerminateReceiveEDMA", "a00041.html#ga819dcef593d48f3296ee858239802e26", null ],
    [ "SAI_TransferAbortSendEDMA", "a00041.html#ga12925e07667cc1b27915aedd1f718a7a", null ],
    [ "SAI_TransferAbortReceiveEDMA", "a00041.html#ga3bd586da5f41126cbfa92d2baa03620b", null ],
    [ "SAI_TransferGetSendCountEDMA", "a00041.html#ga02aa0e441b0aada0f4875f28f832dc71", null ],
    [ "SAI_TransferGetReceiveCountEDMA", "a00041.html#gae4a1100515e9a05bb61e0039288664a0", null ]
];