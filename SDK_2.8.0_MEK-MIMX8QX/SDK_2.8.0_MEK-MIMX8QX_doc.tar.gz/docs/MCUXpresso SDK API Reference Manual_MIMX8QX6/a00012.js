var a00012 =
[
    [ "dpr_buffer_config_t", "a00012.html#a00218", [
      [ "width", "a00012.html#aa3a5d296d23c53285cf50cd2d129002a", null ],
      [ "height", "a00012.html#a6e3509487347ccae511df5d0da746465", null ],
      [ "strideBytes", "a00012.html#a28f5b46429697fbef7293ea683f22bcc", null ],
      [ "dataType", "a00012.html#abcb0463b43835dc02010ac1e8f637608", null ]
    ] ],
    [ "FSL_DPR_DRIVER_VERSION", "a00012.html#ga9b62bdaa58a36941e8c067b158cc26f5", null ],
    [ "dpr_data_type_t", "a00012.html#ga001538d0db8b37f7129be6370002520d", [
      [ "kDPR_DataType16Bpp", "a00012.html#gga001538d0db8b37f7129be6370002520da3cbe1aba541a111350e44fe7e2064ebc", null ],
      [ "kDPR_DataType32Bpp", "a00012.html#gga001538d0db8b37f7129be6370002520daf2d99d9076e9b9a5f05fc35fc51539ff", null ]
    ] ],
    [ "DPR_Init", "a00012.html#gaa17b01c3c39c311e6fedc71dbe1469f5", null ],
    [ "DPR_Deinit", "a00012.html#gabb7cd78b395c72a5ee074ee65e31f67f", null ],
    [ "DPR_SetBufferConfig", "a00012.html#ga0eb64ca0062def9aa0d2e393fa9eb71a", null ],
    [ "DPR_BufferGetDefaultConfig", "a00012.html#gac6fae89d091911cb0013118920a8749f", null ],
    [ "DPR_Start", "a00012.html#ga9aa2943b1be56ee9fa54fc36d5959e7d", null ],
    [ "DPR_StartRepeat", "a00012.html#ga45220356c2b1ece4989c447f7b462d12", null ],
    [ "DPR_Stop", "a00012.html#gac43e8535dc587d701fdf53067494892c", null ],
    [ "DPR_SetBufferAddr", "a00012.html#ga8aa3fc0f45651ba0408c745e6b320592", null ]
];