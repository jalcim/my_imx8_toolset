var a00163 =
[
    [ "FSL_CI_PI_DRIVER_VERSION", "a00163.html#gac45a5dbade3199bafa5181f589a70a02", null ],
    [ "_ci_pi_flags", "a00163.html#ga7940d0e748371df5ee10c0d798447aee", [
      [ "kCI_PI_ChangeOfFieldFlag", "a00163.html#gga7940d0e748371df5ee10c0d798447aeea24a3c937e44dc6559f1e78a121c47952", null ],
      [ "kCI_PI_EccErrorFlag", "a00163.html#gga7940d0e748371df5ee10c0d798447aeea3a82ef578ee0694cc931be7b409b1435", null ]
    ] ],
    [ "ci_pi_input_format_t", "a00163.html#gaf31fd43363f175e428d3c9b46192a4a4", [
      [ "kCI_PI_InputUYVY8888_8BitBus", "a00163.html#ggaf31fd43363f175e428d3c9b46192a4a4aeb1b125b83d841c4d1064357dc5c772e", null ],
      [ "kCI_PI_InputUYVY10101010_10BitBus", "a00163.html#ggaf31fd43363f175e428d3c9b46192a4a4af018a100457794a9a5eb0d381ae9f36e", null ],
      [ "kCI_PI_InputRGB888_8BitBus", "a00163.html#ggaf31fd43363f175e428d3c9b46192a4a4a294048af5be96b713973691055bb60e4", null ],
      [ "kCI_PI_InputBGR888_8BitBus", "a00163.html#ggaf31fd43363f175e428d3c9b46192a4a4a2dc1d86c5405a7c3c9bee85ac360f184", null ],
      [ "kCI_PI_InputRGB888_24BitBus", "a00163.html#ggaf31fd43363f175e428d3c9b46192a4a4ae4ca05ec1c4281aa9408fc7628553fdf", null ],
      [ "kCI_PI_InputYVYU8888_8BitBus", "a00163.html#ggaf31fd43363f175e428d3c9b46192a4a4a17133765f43c5d29d5f8dc8d6a5c6eed", null ],
      [ "kCI_PI_InputYUV888_8BitBus", "a00163.html#ggaf31fd43363f175e428d3c9b46192a4a4aa179edce1bc1454a2d1114a8fc787bdb", null ],
      [ "kCI_PI_InputYVYU8888_16BitBus", "a00163.html#ggaf31fd43363f175e428d3c9b46192a4a4ad9456a23a6f8ba64bb78f4ca5d3eb275", null ],
      [ "kCI_PI_InputYUV888_24BitBus", "a00163.html#ggaf31fd43363f175e428d3c9b46192a4a4a36fbea97fea2df49b6248e221cdfcfb1", null ],
      [ "kCI_PI_InputBayer8_8BitBus", "a00163.html#ggaf31fd43363f175e428d3c9b46192a4a4a12a39051581fa4edf03a9a4d2a140132", null ],
      [ "kCI_PI_InputBayer10_10BitBus", "a00163.html#ggaf31fd43363f175e428d3c9b46192a4a4aa006e7ee09d5ad15cb3058976f12e3f3", null ],
      [ "kCI_PI_InputBayer12_12BitBus", "a00163.html#ggaf31fd43363f175e428d3c9b46192a4a4a5c2a9d50e74674ca76fe532b1982f4f3", null ],
      [ "kCI_PI_InputBayer16_16BitBus", "a00163.html#ggaf31fd43363f175e428d3c9b46192a4a4acbe13c464da3f247ba42403ec21d5fb0", null ]
    ] ],
    [ "_ci_pi_polarity_flags", "a00163.html#ga8c844c3e2acdc39eb8409e05b74f2196", [
      [ "kCI_PI_HsyncActiveLow", "a00163.html#gga8c844c3e2acdc39eb8409e05b74f2196ab9384adc5a1acb8cf3f73d3468f2692f", null ],
      [ "kCI_PI_HsyncActiveHigh", "a00163.html#gga8c844c3e2acdc39eb8409e05b74f2196acf2033f9d21cfdb70d11b63ffb1dee80", null ],
      [ "kCI_PI_DataLatchOnRisingEdge", "a00163.html#gga8c844c3e2acdc39eb8409e05b74f2196a622488f0e23f801b43dc1f901f9669f7", null ],
      [ "kCI_PI_DataLatchOnFallingEdge", "a00163.html#gga8c844c3e2acdc39eb8409e05b74f2196a94944e33dccf912fa5e098f8481d1d9b", null ],
      [ "kCI_PI_DataEnableActiveHigh", "a00163.html#gga8c844c3e2acdc39eb8409e05b74f2196ad84ec096d9d9512227a187559b382651", null ],
      [ "kCI_PI_DataEnableActiveLow", "a00163.html#gga8c844c3e2acdc39eb8409e05b74f2196a77f856be2f3f850bf2fbeb65593247b4", null ],
      [ "kCI_PI_VsyncActiveHigh", "a00163.html#gga8c844c3e2acdc39eb8409e05b74f2196aaa247d51bf56a15b917fb086e7e3b70f", null ],
      [ "kCI_PI_VsyncActiveLow", "a00163.html#gga8c844c3e2acdc39eb8409e05b74f2196af8fc639ba478d5df65f72855414ac8f1", null ]
    ] ],
    [ "ci_pi_work_mode_t", "a00163.html#ga77a4162e5ef544d80ffbc627b325f9bb", [
      [ "kCI_PI_GatedClockMode", "a00163.html#gga77a4162e5ef544d80ffbc627b325f9bba1df3422092391a0e9dd717884c5ba955", null ],
      [ "kCI_PI_GatedClockDataEnableMode", "a00163.html#gga77a4162e5ef544d80ffbc627b325f9bbafc429998886f6137e07eea5565a240ff", null ],
      [ "kCI_PI_NonGatedClockMode", "a00163.html#gga77a4162e5ef544d80ffbc627b325f9bba2f0b9ee486e5a088712250f890eba70d", null ],
      [ "kCI_PI_CCIR656ProgressiveMode", "a00163.html#gga77a4162e5ef544d80ffbc627b325f9bbae2534c0c418a4385ae6ceffb8f4ee8c7", null ]
    ] ],
    [ "CI_PI_Init", "a00163.html#ga52f42310726329423768bc9fbfcb6dc9", null ],
    [ "CI_PI_Deinit", "a00163.html#ga0cdc918612cf0ebaf97c9827edb34adb", null ],
    [ "CI_PI_GetDefaultConfig", "a00163.html#ga68e8b365e5681a931a197a7cbc8fedd6", null ],
    [ "CI_PI_Reset", "a00163.html#ga887293f0f18ddee20b775eb7c25df773", null ],
    [ "CI_PI_Start", "a00163.html#ga96ce0a599e89db58910a48218da97845", null ],
    [ "CI_PI_Stop", "a00163.html#ga5ddea62f43c15bf9cd956d83c2cc62c6", null ],
    [ "CI_PI_GetStatus", "a00163.html#ga8c824ad61fbea64ba6063a9d832425e0", null ]
];